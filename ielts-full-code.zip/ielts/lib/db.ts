import {env} from 'cloudflare:workers';
import {items,COURSE_VERSION} from './course';
import {validSession,dateKey,Stats,Row} from './learning';
export function db(){const d=(env as unknown as {DB?:D1Database}).DB;if(!d)throw new Error('Database unavailable');return d;}
type Attempt={item_id:string;correct:number;hinted:number;xp:number;created:number;day:string;stage:string;independent:number;course_version:string};
export async function progress(userId:string):Promise<Stats>{
 const data=await db().prepare('SELECT item_id,correct,hinted,xp,created,day,stage,independent,course_version FROM attempts WHERE user_id=? ORDER BY created ASC').bind(userId).all<Attempt>();
 const session=await db().prepare('SELECT state,revision FROM learning_sessions WHERE user_id=?').bind(userId).first<{state:string;revision:number}>();
 const maps=new Map<string,Row>(),days=new Map<string,number>(),recalls=new Map<string,Set<string>>();let xp=0,legacyCount=0;
 for(const a of data.results){xp+=a.xp;const known=a.item_id.startsWith('web-')||items.some(i=>i.id===a.item_id);if(!known)legacyCount++;if(a.correct&&a.stage!=='A')days.set(a.day,(days.get(a.day)||0)+1);if(!known)continue;
 let row=maps.get(a.item_id);if(!row){row={item_id:a.item_id,wins:0,last:0,mistakes:0,recallDays:0,due:0,stage:a.stage};maps.set(a.item_id,row);recalls.set(a.item_id,new Set());}
 const independent=a.independent===1||(a.course_version==='1.0'&&a.correct===1&&a.hinted===0);
 row.last=a.created;row.stage=a.stage;if(!a.correct){row.mistakes++;row.due=a.created;}
 if(a.correct&&independent){row.wins++;recalls.get(a.item_id)!.add(a.day);row.recallDays=recalls.get(a.item_id)!.size;const interval=[1,3,7,14,30][Math.min(4,row.recallDays-1)];row.due=a.created+interval*86400000;}
 else if(!row.due)row.due=a.created;
 }
 let saved=null;try{const v=session?JSON.parse(session.state):null;if(validSession(v))saved=v;}catch{}
 return {rows:[...maps.values()],summary:{xp,total:data.results.length},days:[...days].map(([day,count])=>({day,count})).sort((a,b)=>b.day.localeCompare(a.day)),session:saved,revision:session?.revision||0,legacyCount};
}

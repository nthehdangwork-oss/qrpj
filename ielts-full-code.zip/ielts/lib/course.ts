export type Chunk={en:string;vi:string[];target:boolean;start:number;end:number;viSpans:number[][]};
export type Item={id:string;level:number;unit:number;title:string;vi:string;en:string;frames:string[];prompt?:string;minWords?:number;chunks:Chunk[];topic:string;register:string;family:string;sentenceType:string;difficulty:number;source:string;reviewStatus:string;reviewer:null;reviewedAt:null;sentences?:{en:string;vi:string}[];sections?:{en:string;vi:string;label:string}[]};
export const COURSE_VERSION='1.2';
export const items:Item[] = [
  {
    "id": "v2-s1",
    "level": 1,
    "unit": 0,
    "title": "Quan điểm",
    "vi": "Theo quan điểm của tôi, giao thông công cộng miễn phí sẽ mang lại lợi ích cho cả cư dân thành phố lẫn môi trường.",
    "en": "From my perspective, free public transport would benefit both city residents and the environment.",
    "frames": [
      "From my perspective"
    ],
    "chunks": [
      {
        "en": "From my perspective,",
        "vi": [
          "Theo quan điểm của tôi,"
        ],
        "target": true,
        "start": 0,
        "end": 20,
        "viSpans": [
          [
            0,
            23
          ]
        ]
      },
      {
        "en": "free public transport",
        "vi": [
          "giao thông công cộng miễn phí"
        ],
        "target": false,
        "start": 21,
        "end": 42,
        "viSpans": [
          [
            24,
            53
          ]
        ]
      },
      {
        "en": "would benefit",
        "vi": [
          "sẽ mang lại lợi ích cho"
        ],
        "target": false,
        "start": 43,
        "end": 56,
        "viSpans": [
          [
            54,
            77
          ]
        ]
      },
      {
        "en": "both city residents and the environment.",
        "vi": [
          "cả cư dân thành phố lẫn môi trường."
        ],
        "target": false,
        "start": 57,
        "end": 97,
        "viSpans": [
          [
            78,
            113
          ]
        ]
      }
    ],
    "topic": "city",
    "register": "Writing",
    "family": "f1",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s2",
    "level": 1,
    "unit": 0,
    "title": "Quan điểm",
    "vi": "Tôi cho rằng các trường học nên ưu tiên tư duy phản biện hơn là học thuộc lòng.",
    "en": "I would argue that schools should prioritise critical thinking over rote memorisation.",
    "frames": [
      "I would argue that"
    ],
    "chunks": [
      {
        "en": "I would argue that",
        "vi": [
          "Tôi cho rằng"
        ],
        "target": true,
        "start": 0,
        "end": 18,
        "viSpans": [
          [
            0,
            12
          ]
        ]
      },
      {
        "en": "schools should prioritise",
        "vi": [
          "các trường học nên ưu tiên"
        ],
        "target": false,
        "start": 19,
        "end": 44,
        "viSpans": [
          [
            13,
            39
          ]
        ]
      },
      {
        "en": "critical thinking",
        "vi": [
          "tư duy phản biện"
        ],
        "target": false,
        "start": 45,
        "end": 62,
        "viSpans": [
          [
            40,
            56
          ]
        ]
      },
      {
        "en": "over rote memorisation.",
        "vi": [
          "hơn là học thuộc lòng."
        ],
        "target": false,
        "start": 63,
        "end": 86,
        "viSpans": [
          [
            57,
            79
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f2",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s3",
    "level": 1,
    "unit": 0,
    "title": "Quan điểm",
    "vi": "Ở mức độ lớn, tôi đồng ý rằng chính phủ nên quản lý nội dung mà trẻ em xem trên mạng.",
    "en": "To a large extent, I agree that governments should regulate the content that children see online.",
    "frames": [
      "To a large extent, I agree that"
    ],
    "chunks": [
      {
        "en": "To a large extent, I agree that",
        "vi": [
          "Ở mức độ lớn, tôi đồng ý rằng"
        ],
        "target": true,
        "start": 0,
        "end": 31,
        "viSpans": [
          [
            0,
            29
          ]
        ]
      },
      {
        "en": "governments should regulate",
        "vi": [
          "chính phủ nên quản lý"
        ],
        "target": false,
        "start": 32,
        "end": 59,
        "viSpans": [
          [
            30,
            51
          ]
        ]
      },
      {
        "en": "the content",
        "vi": [
          "nội dung"
        ],
        "target": false,
        "start": 60,
        "end": 71,
        "viSpans": [
          [
            52,
            60
          ]
        ]
      },
      {
        "en": "that children see online.",
        "vi": [
          "mà trẻ em xem trên mạng."
        ],
        "target": false,
        "start": 72,
        "end": 97,
        "viSpans": [
          [
            61,
            85
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f3",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s4",
    "level": 1,
    "unit": 0,
    "title": "Lý do",
    "vi": "Một trong những lý do chính là làm việc từ xa loại bỏ nhu cầu đi lại dài mỗi ngày.",
    "en": "One of the main reasons is that remote work removes the need for long daily commutes.",
    "frames": [
      "One of the main reasons is that"
    ],
    "chunks": [
      {
        "en": "One of the main reasons is that",
        "vi": [
          "Một trong những lý do chính là"
        ],
        "target": true,
        "start": 0,
        "end": 31,
        "viSpans": [
          [
            0,
            30
          ]
        ]
      },
      {
        "en": "remote work",
        "vi": [
          "làm việc từ xa"
        ],
        "target": false,
        "start": 32,
        "end": 43,
        "viSpans": [
          [
            31,
            45
          ]
        ]
      },
      {
        "en": "removes the need for",
        "vi": [
          "loại bỏ nhu cầu"
        ],
        "target": false,
        "start": 44,
        "end": 64,
        "viSpans": [
          [
            46,
            61
          ]
        ]
      },
      {
        "en": "long daily commutes.",
        "vi": [
          "đi lại dài mỗi ngày."
        ],
        "target": false,
        "start": 65,
        "end": 85,
        "viSpans": [
          [
            62,
            82
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Writing",
    "family": "f4",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s5",
    "level": 1,
    "unit": 0,
    "title": "Lý do",
    "vi": "Điều này chủ yếu là do những thói quen lành mạnh hình thành từ nhỏ thường kéo dài đến tuổi trưởng thành.",
    "en": "This is primarily because healthy habits formed in childhood tend to last into adulthood.",
    "frames": [
      "This is primarily because"
    ],
    "chunks": [
      {
        "en": "This is primarily because",
        "vi": [
          "Điều này chủ yếu là do"
        ],
        "target": true,
        "start": 0,
        "end": 25,
        "viSpans": [
          [
            0,
            22
          ]
        ]
      },
      {
        "en": "healthy habits formed in childhood",
        "vi": [
          "những thói quen lành mạnh hình thành từ nhỏ"
        ],
        "target": false,
        "start": 26,
        "end": 60,
        "viSpans": [
          [
            23,
            66
          ]
        ]
      },
      {
        "en": "tend to last",
        "vi": [
          "thường kéo dài"
        ],
        "target": false,
        "start": 61,
        "end": 73,
        "viSpans": [
          [
            67,
            81
          ]
        ]
      },
      {
        "en": "into adulthood.",
        "vi": [
          "đến tuổi trưởng thành."
        ],
        "target": false,
        "start": 74,
        "end": 89,
        "viSpans": [
          [
            82,
            104
          ]
        ]
      }
    ],
    "topic": "health",
    "register": "Writing",
    "family": "f5",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s6",
    "level": 1,
    "unit": 1,
    "title": "Thêm ý",
    "vi": "Một điều cần cân nhắc nữa là năng lượng tái tạo ngày càng rẻ hơn khi công nghệ được cải thiện.",
    "en": "Another important consideration is that renewable energy becomes cheaper as the technology improves.",
    "frames": [
      "Another important consideration is that"
    ],
    "chunks": [
      {
        "en": "Another important consideration is that",
        "vi": [
          "Một điều cần cân nhắc nữa là"
        ],
        "target": true,
        "start": 0,
        "end": 39,
        "viSpans": [
          [
            0,
            28
          ]
        ]
      },
      {
        "en": "renewable energy becomes cheaper",
        "vi": [
          "năng lượng tái tạo ngày càng rẻ hơn"
        ],
        "target": false,
        "start": 40,
        "end": 72,
        "viSpans": [
          [
            29,
            64
          ]
        ]
      },
      {
        "en": "as the technology improves.",
        "vi": [
          "khi công nghệ được cải thiện."
        ],
        "target": false,
        "start": 73,
        "end": 100,
        "viSpans": [
          [
            65,
            94
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f6",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s7",
    "level": 1,
    "unit": 1,
    "title": "Thêm ý",
    "vi": "Hơn nữa, các nhà tuyển dụng ngày càng coi trọng những ứng viên có thể thích nghi nhanh với công cụ mới.",
    "en": "Furthermore, employers increasingly value candidates who can adapt quickly to new tools.",
    "frames": [
      "Furthermore"
    ],
    "chunks": [
      {
        "en": "Furthermore,",
        "vi": [
          "Hơn nữa,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            8
          ]
        ]
      },
      {
        "en": "employers increasingly value",
        "vi": [
          "các nhà tuyển dụng ngày càng coi trọng"
        ],
        "target": false,
        "start": 13,
        "end": 41,
        "viSpans": [
          [
            9,
            47
          ]
        ]
      },
      {
        "en": "candidates",
        "vi": [
          "những ứng viên"
        ],
        "target": false,
        "start": 42,
        "end": 52,
        "viSpans": [
          [
            48,
            62
          ]
        ]
      },
      {
        "en": "who can adapt quickly to new tools.",
        "vi": [
          "có thể thích nghi nhanh với công cụ mới."
        ],
        "target": false,
        "start": 53,
        "end": 88,
        "viSpans": [
          [
            63,
            103
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Writing",
    "family": "f7",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s8",
    "level": 1,
    "unit": 1,
    "title": "Ví dụ",
    "vi": "Ví dụ, nhiều thành phố đã khuyến khích người dân đạp xe nhiều hơn bằng cách xây dựng làn đường dành riêng cho xe đạp.",
    "en": "For example, many cities have encouraged more people to cycle by building dedicated bike lanes.",
    "frames": [
      "For example"
    ],
    "chunks": [
      {
        "en": "For example,",
        "vi": [
          "Ví dụ,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            6
          ]
        ]
      },
      {
        "en": "many cities have encouraged",
        "vi": [
          "nhiều thành phố đã khuyến khích"
        ],
        "target": false,
        "start": 13,
        "end": 40,
        "viSpans": [
          [
            7,
            38
          ]
        ]
      },
      {
        "en": "more people to cycle",
        "vi": [
          "người dân đạp xe nhiều hơn"
        ],
        "target": false,
        "start": 41,
        "end": 61,
        "viSpans": [
          [
            39,
            65
          ]
        ]
      },
      {
        "en": "by building dedicated bike lanes.",
        "vi": [
          "bằng cách xây dựng làn đường dành riêng cho xe đạp."
        ],
        "target": false,
        "start": 62,
        "end": 95,
        "viSpans": [
          [
            66,
            117
          ]
        ]
      }
    ],
    "topic": "city",
    "register": "Writing",
    "family": "f8",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s9",
    "level": 1,
    "unit": 1,
    "title": "Ví dụ",
    "vi": "Một ví dụ điển hình là các ứng dụng học ngôn ngữ, cho phép người dùng luyện tập chỉ vài phút mỗi ngày.",
    "en": "A good example of this is language-learning apps, which allow people to practise for just a few minutes a day.",
    "frames": [
      "A good example of this is"
    ],
    "chunks": [
      {
        "en": "A good example of this is",
        "vi": [
          "Một ví dụ điển hình là"
        ],
        "target": true,
        "start": 0,
        "end": 25,
        "viSpans": [
          [
            0,
            22
          ]
        ]
      },
      {
        "en": "language-learning apps,",
        "vi": [
          "các ứng dụng học ngôn ngữ,"
        ],
        "target": false,
        "start": 26,
        "end": 49,
        "viSpans": [
          [
            23,
            49
          ]
        ]
      },
      {
        "en": "which allow people to practise",
        "vi": [
          "cho phép người dùng luyện tập"
        ],
        "target": false,
        "start": 50,
        "end": 80,
        "viSpans": [
          [
            50,
            79
          ]
        ]
      },
      {
        "en": "for just a few minutes a day.",
        "vi": [
          "chỉ vài phút mỗi ngày."
        ],
        "target": false,
        "start": 81,
        "end": 110,
        "viSpans": [
          [
            80,
            102
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f9",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s10",
    "level": 1,
    "unit": 1,
    "title": "Ví dụ",
    "vi": "Lấy mua sắm trực tuyến làm ví dụ: nó tiết kiệm thời gian nhưng cũng khuyến khích chi tiêu bốc đồng.",
    "en": "Take online shopping, for example: it saves time, yet it also encourages impulse spending.",
    "frames": [
      "Take",
      "for example"
    ],
    "chunks": [
      {
        "en": "Take online shopping, for example:",
        "vi": [
          "Lấy mua sắm trực tuyến làm ví dụ:"
        ],
        "target": true,
        "start": 0,
        "end": 34,
        "viSpans": [
          [
            0,
            33
          ]
        ]
      },
      {
        "en": "it saves time,",
        "vi": [
          "nó tiết kiệm thời gian"
        ],
        "target": false,
        "start": 35,
        "end": 49,
        "viSpans": [
          [
            34,
            56
          ]
        ]
      },
      {
        "en": "yet it also encourages impulse spending.",
        "vi": [
          "nhưng cũng khuyến khích chi tiêu bốc đồng."
        ],
        "target": false,
        "start": 50,
        "end": 90,
        "viSpans": [
          [
            57,
            99
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f10",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s11",
    "level": 1,
    "unit": 2,
    "title": "Kết quả",
    "vi": "Kết quả là bệnh nhân ở vùng xa có thể hỏi ý kiến chuyên gia mà không phải di chuyển hàng giờ.",
    "en": "As a result, patients in remote areas can consult specialists without travelling for hours.",
    "frames": [
      "As a result"
    ],
    "chunks": [
      {
        "en": "As a result,",
        "vi": [
          "Kết quả là"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            10
          ]
        ]
      },
      {
        "en": "patients in remote areas",
        "vi": [
          "bệnh nhân ở vùng xa"
        ],
        "target": false,
        "start": 13,
        "end": 37,
        "viSpans": [
          [
            11,
            30
          ]
        ]
      },
      {
        "en": "can consult specialists",
        "vi": [
          "có thể hỏi ý kiến chuyên gia"
        ],
        "target": false,
        "start": 38,
        "end": 61,
        "viSpans": [
          [
            31,
            59
          ]
        ]
      },
      {
        "en": "without travelling for hours.",
        "vi": [
          "mà không phải di chuyển hàng giờ."
        ],
        "target": false,
        "start": 62,
        "end": 91,
        "viSpans": [
          [
            60,
            93
          ]
        ]
      }
    ],
    "topic": "health",
    "register": "Writing",
    "family": "f11",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s12",
    "level": 1,
    "unit": 2,
    "title": "Kết quả",
    "vi": "Do đó, nhiều sinh viên tốt nghiệp khó tìm được việc làm phù hợp với trình độ của mình.",
    "en": "Consequently, many graduates struggle to find jobs that match their qualifications.",
    "frames": [
      "Consequently"
    ],
    "chunks": [
      {
        "en": "Consequently,",
        "vi": [
          "Do đó,"
        ],
        "target": true,
        "start": 0,
        "end": 13,
        "viSpans": [
          [
            0,
            6
          ]
        ]
      },
      {
        "en": "many graduates struggle to find jobs",
        "vi": [
          "nhiều sinh viên tốt nghiệp khó tìm được việc làm"
        ],
        "target": false,
        "start": 14,
        "end": 50,
        "viSpans": [
          [
            7,
            55
          ]
        ]
      },
      {
        "en": "that match their qualifications.",
        "vi": [
          "phù hợp với trình độ của mình."
        ],
        "target": false,
        "start": 51,
        "end": 83,
        "viSpans": [
          [
            56,
            86
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f12",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s13",
    "level": 1,
    "unit": 2,
    "title": "Tác động",
    "vi": "Tập thể dục thường xuyên có thể tác động đáng kể đến cả sức khỏe thể chất lẫn tinh thần.",
    "en": "Regular exercise can have a significant impact on both physical health and mental well-being.",
    "frames": [
      "can have a significant impact on"
    ],
    "chunks": [
      {
        "en": "Regular exercise",
        "vi": [
          "Tập thể dục thường xuyên"
        ],
        "target": false,
        "start": 0,
        "end": 16,
        "viSpans": [
          [
            0,
            24
          ]
        ]
      },
      {
        "en": "can have a significant impact on",
        "vi": [
          "có thể tác động đáng kể đến"
        ],
        "target": true,
        "start": 17,
        "end": 49,
        "viSpans": [
          [
            25,
            52
          ]
        ]
      },
      {
        "en": "both physical health and mental well-being.",
        "vi": [
          "cả sức khỏe thể chất lẫn tinh thần."
        ],
        "target": false,
        "start": 50,
        "end": 93,
        "viSpans": [
          [
            53,
            88
          ]
        ]
      }
    ],
    "topic": "health",
    "register": "Writing",
    "family": "f13",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s14",
    "level": 1,
    "unit": 2,
    "title": "Tác động",
    "vi": "Công nghệ giúp con người làm việc hiệu quả hơn.",
    "en": "Technology enables people to work more efficiently.",
    "frames": [
      "enables people to"
    ],
    "chunks": [
      {
        "en": "Technology",
        "vi": [
          "Công nghệ"
        ],
        "target": false,
        "start": 0,
        "end": 10,
        "viSpans": [
          [
            0,
            9
          ]
        ]
      },
      {
        "en": "enables people to",
        "vi": [
          "giúp con người"
        ],
        "target": true,
        "start": 11,
        "end": 28,
        "viSpans": [
          [
            10,
            24
          ]
        ]
      },
      {
        "en": "work more efficiently.",
        "vi": [
          "làm việc hiệu quả hơn."
        ],
        "target": false,
        "start": 29,
        "end": 51,
        "viSpans": [
          [
            25,
            47
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f14",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s15",
    "level": 1,
    "unit": 2,
    "title": "Áp lực",
    "vi": "Chi phí nhà ở tăng cao có thể gây áp lực đáng kể lên các gia đình trẻ.",
    "en": "Rising housing costs can place considerable pressure on young families.",
    "frames": [
      "can place considerable pressure on"
    ],
    "chunks": [
      {
        "en": "Rising housing costs",
        "vi": [
          "Chi phí nhà ở tăng cao"
        ],
        "target": false,
        "start": 0,
        "end": 20,
        "viSpans": [
          [
            0,
            22
          ]
        ]
      },
      {
        "en": "can place considerable pressure on",
        "vi": [
          "có thể gây áp lực đáng kể lên"
        ],
        "target": true,
        "start": 21,
        "end": 55,
        "viSpans": [
          [
            23,
            52
          ]
        ]
      },
      {
        "en": "young families.",
        "vi": [
          "các gia đình trẻ."
        ],
        "target": false,
        "start": 56,
        "end": 71,
        "viSpans": [
          [
            53,
            70
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Writing",
    "family": "f15",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s16",
    "level": 1,
    "unit": 3,
    "title": "Cơ hội",
    "vi": "Hoạt động tình nguyện mang đến cho người trẻ cơ hội phát triển kỹ năng làm việc nhóm và lãnh đạo.",
    "en": "Volunteering provides young people with opportunities to develop teamwork and leadership skills.",
    "frames": [
      "provides young people with opportunities to"
    ],
    "chunks": [
      {
        "en": "Volunteering",
        "vi": [
          "Hoạt động tình nguyện"
        ],
        "target": false,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            21
          ]
        ]
      },
      {
        "en": "provides young people with opportunities to",
        "vi": [
          "mang đến cho người trẻ cơ hội"
        ],
        "target": true,
        "start": 13,
        "end": 56,
        "viSpans": [
          [
            22,
            51
          ]
        ]
      },
      {
        "en": "develop teamwork and leadership skills.",
        "vi": [
          "phát triển kỹ năng làm việc nhóm và lãnh đạo."
        ],
        "target": false,
        "start": 57,
        "end": 96,
        "viSpans": [
          [
            52,
            97
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Writing",
    "family": "f16",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s17",
    "level": 1,
    "unit": 3,
    "title": "Đóng góp",
    "vi": "Du lịch có thể đóng góp cho kinh tế địa phương bằng cách tạo việc làm và hỗ trợ các doanh nghiệp nhỏ.",
    "en": "Tourism can contribute to local economies by creating jobs and supporting small businesses.",
    "frames": [
      "can contribute to"
    ],
    "chunks": [
      {
        "en": "Tourism",
        "vi": [
          "Du lịch"
        ],
        "target": false,
        "start": 0,
        "end": 7,
        "viSpans": [
          [
            0,
            7
          ]
        ]
      },
      {
        "en": "can contribute to",
        "vi": [
          "có thể đóng góp cho"
        ],
        "target": true,
        "start": 8,
        "end": 25,
        "viSpans": [
          [
            8,
            27
          ]
        ]
      },
      {
        "en": "local economies",
        "vi": [
          "kinh tế địa phương"
        ],
        "target": false,
        "start": 26,
        "end": 41,
        "viSpans": [
          [
            28,
            46
          ]
        ]
      },
      {
        "en": "by creating jobs and supporting small businesses.",
        "vi": [
          "bằng cách tạo việc làm và hỗ trợ các doanh nghiệp nhỏ."
        ],
        "target": false,
        "start": 42,
        "end": 91,
        "viSpans": [
          [
            47,
            101
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "f17",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s18",
    "level": 1,
    "unit": 3,
    "title": "Vai trò",
    "vi": "Giáo dục đóng vai trò then chốt trong việc giảm bất bình đẳng giữa các nhóm xã hội khác nhau.",
    "en": "Education plays a crucial role in reducing inequality between different social groups.",
    "frames": [
      "plays a crucial role in"
    ],
    "chunks": [
      {
        "en": "Education",
        "vi": [
          "Giáo dục"
        ],
        "target": false,
        "start": 0,
        "end": 9,
        "viSpans": [
          [
            0,
            8
          ]
        ]
      },
      {
        "en": "plays a crucial role in",
        "vi": [
          "đóng vai trò then chốt trong việc"
        ],
        "target": true,
        "start": 10,
        "end": 33,
        "viSpans": [
          [
            9,
            42
          ]
        ]
      },
      {
        "en": "reducing inequality",
        "vi": [
          "giảm bất bình đẳng"
        ],
        "target": false,
        "start": 34,
        "end": 53,
        "viSpans": [
          [
            43,
            61
          ]
        ]
      },
      {
        "en": "between different social groups.",
        "vi": [
          "giữa các nhóm xã hội khác nhau."
        ],
        "target": false,
        "start": 54,
        "end": 86,
        "viSpans": [
          [
            62,
            93
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f18",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s19",
    "level": 1,
    "unit": 3,
    "title": "So sánh",
    "vi": "Trước đây, mọi người thường đọc báo in, trong khi ngày nay hầu hết đọc tin tức trên điện thoại.",
    "en": "In the past, people tended to rely on printed newspapers, whereas nowadays most of them read the news on their phones.",
    "frames": [
      "In the past",
      "whereas nowadays"
    ],
    "chunks": [
      {
        "en": "In the past,",
        "vi": [
          "Trước đây,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            10
          ]
        ]
      },
      {
        "en": "people tended to rely on printed newspapers,",
        "vi": [
          "mọi người thường đọc báo in,"
        ],
        "target": false,
        "start": 13,
        "end": 57,
        "viSpans": [
          [
            11,
            39
          ]
        ]
      },
      {
        "en": "whereas nowadays",
        "vi": [
          "trong khi ngày nay"
        ],
        "target": true,
        "start": 58,
        "end": 74,
        "viSpans": [
          [
            40,
            58
          ]
        ]
      },
      {
        "en": "most of them read the news on their phones.",
        "vi": [
          "hầu hết đọc tin tức trên điện thoại."
        ],
        "target": false,
        "start": 75,
        "end": 118,
        "viSpans": [
          [
            59,
            95
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f19",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s20",
    "level": 1,
    "unit": 3,
    "title": "So sánh",
    "vi": "So với trước đây, học sinh ngày nay dễ tiếp cận thông tin hơn nhiều.",
    "en": "Compared with the past, today's students have far easier access to information.",
    "frames": [
      "Compared with the past"
    ],
    "chunks": [
      {
        "en": "Compared with the past,",
        "vi": [
          "So với trước đây,"
        ],
        "target": true,
        "start": 0,
        "end": 23,
        "viSpans": [
          [
            0,
            17
          ]
        ]
      },
      {
        "en": "today's students",
        "vi": [
          "học sinh ngày nay"
        ],
        "target": false,
        "start": 24,
        "end": 40,
        "viSpans": [
          [
            18,
            35
          ]
        ]
      },
      {
        "en": "have far easier access to",
        "vi": [
          "dễ tiếp cận",
          "hơn nhiều."
        ],
        "target": false,
        "start": 41,
        "end": 66,
        "viSpans": [
          [
            36,
            47
          ],
          [
            58,
            68
          ]
        ]
      },
      {
        "en": "information.",
        "vi": [
          "thông tin"
        ],
        "target": false,
        "start": 67,
        "end": 79,
        "viSpans": [
          [
            48,
            57
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f20",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s21",
    "level": 1,
    "unit": 4,
    "title": "Thừa nhận",
    "vi": "Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn.",
    "en": "Admittedly, studying abroad can be expensive, particularly for families on modest incomes.",
    "frames": [
      "Admittedly"
    ],
    "chunks": [
      {
        "en": "Admittedly,",
        "vi": [
          "Phải thừa nhận rằng"
        ],
        "target": true,
        "start": 0,
        "end": 11,
        "viSpans": [
          [
            0,
            19
          ]
        ]
      },
      {
        "en": "studying abroad can be expensive,",
        "vi": [
          "du học có thể tốn kém,"
        ],
        "target": false,
        "start": 12,
        "end": 45,
        "viSpans": [
          [
            20,
            42
          ]
        ]
      },
      {
        "en": "particularly for families on modest incomes.",
        "vi": [
          "đặc biệt với các gia đình có thu nhập khiêm tốn."
        ],
        "target": false,
        "start": 46,
        "end": 90,
        "viSpans": [
          [
            43,
            91
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "f21",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s22",
    "level": 1,
    "unit": 4,
    "title": "Phản biện",
    "vi": "Tuy nhiên, lập luận này bỏ qua thực tế là nhiều trường đại học cấp học bổng hào phóng.",
    "en": "Nevertheless, this argument overlooks the fact that many universities offer generous scholarships.",
    "frames": [
      "Nevertheless, this argument overlooks the fact that"
    ],
    "chunks": [
      {
        "en": "Nevertheless, this argument overlooks the fact that",
        "vi": [
          "Tuy nhiên, lập luận này bỏ qua thực tế là"
        ],
        "target": true,
        "start": 0,
        "end": 51,
        "viSpans": [
          [
            0,
            41
          ]
        ]
      },
      {
        "en": "many universities",
        "vi": [
          "nhiều trường đại học"
        ],
        "target": false,
        "start": 52,
        "end": 69,
        "viSpans": [
          [
            42,
            62
          ]
        ]
      },
      {
        "en": "offer generous scholarships.",
        "vi": [
          "cấp học bổng hào phóng."
        ],
        "target": false,
        "start": 70,
        "end": 98,
        "viSpans": [
          [
            63,
            86
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f22",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s23",
    "level": 1,
    "unit": 4,
    "title": "Chưa chắc chắn",
    "vi": "Tôi không hoàn toàn chắc, nhưng tôi đoán hầu hết mọi người thích mua sắm trực tuyến vì nó tiện lợi.",
    "en": "I'm not entirely sure, but I'd imagine that most people prefer shopping online because it is convenient.",
    "frames": [
      "I'm not entirely sure, but I'd imagine that"
    ],
    "chunks": [
      {
        "en": "I'm not entirely sure, but I'd imagine that",
        "vi": [
          "Tôi không hoàn toàn chắc, nhưng tôi đoán"
        ],
        "target": true,
        "start": 0,
        "end": 43,
        "viSpans": [
          [
            0,
            40
          ]
        ]
      },
      {
        "en": "most people prefer shopping online",
        "vi": [
          "hầu hết mọi người thích mua sắm trực tuyến"
        ],
        "target": false,
        "start": 44,
        "end": 78,
        "viSpans": [
          [
            41,
            83
          ]
        ]
      },
      {
        "en": "because it is convenient.",
        "vi": [
          "vì nó tiện lợi."
        ],
        "target": false,
        "start": 79,
        "end": 104,
        "viSpans": [
          [
            84,
            99
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Speaking",
    "family": "f23",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s24",
    "level": 1,
    "unit": 4,
    "title": "Tùy trường hợp",
    "vi": "Điều đó thực sự còn tùy tình huống, nhưng nhìn chung tôi thích làm việc nhóm hơn.",
    "en": "It really depends on the situation, but I generally prefer working in a team.",
    "frames": [
      "It really depends on the situation"
    ],
    "chunks": [
      {
        "en": "It really depends on the situation,",
        "vi": [
          "Điều đó thực sự còn tùy tình huống,"
        ],
        "target": true,
        "start": 0,
        "end": 35,
        "viSpans": [
          [
            0,
            35
          ]
        ]
      },
      {
        "en": "but I generally prefer",
        "vi": [
          "nhưng nhìn chung tôi thích",
          "hơn."
        ],
        "target": false,
        "start": 36,
        "end": 58,
        "viSpans": [
          [
            36,
            62
          ],
          [
            77,
            81
          ]
        ]
      },
      {
        "en": "working in a team.",
        "vi": [
          "làm việc nhóm"
        ],
        "target": false,
        "start": 59,
        "end": 77,
        "viSpans": [
          [
            63,
            76
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Speaking",
    "family": "f24",
    "sentenceType": "simple",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-s25",
    "level": 1,
    "unit": 4,
    "title": "Lựa chọn",
    "vi": "Nếu phải chọn, có lẽ tôi sẽ dành thời gian rảnh ở ngoài trời hơn là trong nhà.",
    "en": "If I had to choose, I'd probably spend my free time outdoors rather than indoors.",
    "frames": [
      "If I had to choose, I'd probably"
    ],
    "chunks": [
      {
        "en": "If I had to choose, I'd probably",
        "vi": [
          "Nếu phải chọn, có lẽ tôi sẽ"
        ],
        "target": true,
        "start": 0,
        "end": 32,
        "viSpans": [
          [
            0,
            27
          ]
        ]
      },
      {
        "en": "spend my free time outdoors",
        "vi": [
          "dành thời gian rảnh ở ngoài trời"
        ],
        "target": false,
        "start": 33,
        "end": 60,
        "viSpans": [
          [
            28,
            60
          ]
        ]
      },
      {
        "en": "rather than indoors.",
        "vi": [
          "hơn là trong nhà."
        ],
        "target": false,
        "start": 61,
        "end": 81,
        "viSpans": [
          [
            61,
            78
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Speaking",
    "family": "f25",
    "sentenceType": "complex",
    "difficulty": 1,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t1",
    "level": 2,
    "unit": 0,
    "title": "Tác động",
    "vi": "Học trực tuyến giúp mọi người học tập linh hoạt hơn.",
    "en": "Online learning enables people to study more flexibly.",
    "frames": [
      "enables people to"
    ],
    "chunks": [
      {
        "en": "Online learning",
        "vi": [
          "Học trực tuyến"
        ],
        "target": false,
        "start": 0,
        "end": 15,
        "viSpans": [
          [
            0,
            14
          ]
        ]
      },
      {
        "en": "enables people to",
        "vi": [
          "giúp mọi người"
        ],
        "target": true,
        "start": 16,
        "end": 33,
        "viSpans": [
          [
            15,
            29
          ]
        ]
      },
      {
        "en": "study more flexibly.",
        "vi": [
          "học tập linh hoạt hơn."
        ],
        "target": false,
        "start": 34,
        "end": 54,
        "viSpans": [
          [
            30,
            52
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f14",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t2",
    "level": 2,
    "unit": 0,
    "title": "Lý do",
    "vi": "Một trong những lý do chính là ngân hàng trực tuyến loại bỏ nhu cầu xếp hàng tại chi nhánh.",
    "en": "One of the main reasons is that online banking removes the need for queuing at branches.",
    "frames": [
      "One of the main reasons is that"
    ],
    "chunks": [
      {
        "en": "One of the main reasons is that",
        "vi": [
          "Một trong những lý do chính là"
        ],
        "target": true,
        "start": 0,
        "end": 31,
        "viSpans": [
          [
            0,
            30
          ]
        ]
      },
      {
        "en": "online banking",
        "vi": [
          "ngân hàng trực tuyến"
        ],
        "target": false,
        "start": 32,
        "end": 46,
        "viSpans": [
          [
            31,
            51
          ]
        ]
      },
      {
        "en": "removes the need for",
        "vi": [
          "loại bỏ nhu cầu"
        ],
        "target": false,
        "start": 47,
        "end": 67,
        "viSpans": [
          [
            52,
            67
          ]
        ]
      },
      {
        "en": "queuing at branches.",
        "vi": [
          "xếp hàng tại chi nhánh."
        ],
        "target": false,
        "start": 68,
        "end": 88,
        "viSpans": [
          [
            68,
            91
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f4",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t3",
    "level": 2,
    "unit": 0,
    "title": "Vai trò",
    "vi": "Thư viện công cộng đóng vai trò then chốt trong việc thúc đẩy học tập suốt đời.",
    "en": "Public libraries play a crucial role in promoting lifelong learning.",
    "frames": [
      "play a crucial role in"
    ],
    "chunks": [
      {
        "en": "Public libraries",
        "vi": [
          "Thư viện công cộng"
        ],
        "target": false,
        "start": 0,
        "end": 16,
        "viSpans": [
          [
            0,
            18
          ]
        ]
      },
      {
        "en": "play a crucial role in",
        "vi": [
          "đóng vai trò then chốt trong việc"
        ],
        "target": true,
        "start": 17,
        "end": 39,
        "viSpans": [
          [
            19,
            52
          ]
        ]
      },
      {
        "en": "promoting lifelong learning.",
        "vi": [
          "thúc đẩy học tập suốt đời."
        ],
        "target": false,
        "start": 40,
        "end": 68,
        "viSpans": [
          [
            53,
            79
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Writing",
    "family": "f18",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t4",
    "level": 2,
    "unit": 0,
    "title": "Tác động",
    "vi": "Mạng xã hội có thể tác động đáng kể đến cách thanh thiếu niên nhìn nhận bản thân.",
    "en": "Social media can have a significant impact on how teenagers see themselves.",
    "frames": [
      "can have a significant impact on"
    ],
    "chunks": [
      {
        "en": "Social media",
        "vi": [
          "Mạng xã hội"
        ],
        "target": false,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            11
          ]
        ]
      },
      {
        "en": "can have a significant impact on",
        "vi": [
          "có thể tác động đáng kể đến"
        ],
        "target": true,
        "start": 13,
        "end": 45,
        "viSpans": [
          [
            12,
            39
          ]
        ]
      },
      {
        "en": "how teenagers see themselves.",
        "vi": [
          "cách thanh thiếu niên nhìn nhận bản thân."
        ],
        "target": false,
        "start": 46,
        "end": 75,
        "viSpans": [
          [
            40,
            81
          ]
        ]
      }
    ],
    "topic": "technology",
    "register": "Writing",
    "family": "f13",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t5",
    "level": 2,
    "unit": 0,
    "title": "Cơ hội",
    "vi": "Thực tập mang đến cho sinh viên mới tốt nghiệp cơ hội tích lũy kinh nghiệm thực tế.",
    "en": "Internships provide graduates with opportunities to gain practical experience.",
    "frames": [
      "provide graduates with opportunities to"
    ],
    "chunks": [
      {
        "en": "Internships",
        "vi": [
          "Thực tập"
        ],
        "target": false,
        "start": 0,
        "end": 11,
        "viSpans": [
          [
            0,
            8
          ]
        ]
      },
      {
        "en": "provide graduates with opportunities to",
        "vi": [
          "mang đến cho sinh viên mới tốt nghiệp cơ hội"
        ],
        "target": true,
        "start": 12,
        "end": 51,
        "viSpans": [
          [
            9,
            53
          ]
        ]
      },
      {
        "en": "gain practical experience.",
        "vi": [
          "tích lũy kinh nghiệm thực tế."
        ],
        "target": false,
        "start": 52,
        "end": 78,
        "viSpans": [
          [
            54,
            83
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Writing",
    "family": "f16",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t6",
    "level": 2,
    "unit": 1,
    "title": "Đóng góp",
    "vi": "Nông nghiệp đô thị có thể góp phần đảm bảo an ninh lương thực ở các thành phố đông dân.",
    "en": "Urban farming can contribute to food security in crowded cities.",
    "frames": [
      "can contribute to"
    ],
    "chunks": [
      {
        "en": "Urban farming",
        "vi": [
          "Nông nghiệp đô thị"
        ],
        "target": false,
        "start": 0,
        "end": 13,
        "viSpans": [
          [
            0,
            18
          ]
        ]
      },
      {
        "en": "can contribute to",
        "vi": [
          "có thể góp phần"
        ],
        "target": true,
        "start": 14,
        "end": 31,
        "viSpans": [
          [
            19,
            34
          ]
        ]
      },
      {
        "en": "food security",
        "vi": [
          "đảm bảo an ninh lương thực"
        ],
        "target": false,
        "start": 32,
        "end": 45,
        "viSpans": [
          [
            35,
            61
          ]
        ]
      },
      {
        "en": "in crowded cities.",
        "vi": [
          "ở các thành phố đông dân."
        ],
        "target": false,
        "start": 46,
        "end": 64,
        "viSpans": [
          [
            62,
            87
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f17",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t7",
    "level": 2,
    "unit": 1,
    "title": "Áp lực",
    "vi": "Giờ làm việc kéo dài có thể gây áp lực đáng kể lên các mối quan hệ cá nhân.",
    "en": "Long working hours can place considerable pressure on personal relationships.",
    "frames": [
      "can place considerable pressure on"
    ],
    "chunks": [
      {
        "en": "Long working hours",
        "vi": [
          "Giờ làm việc kéo dài"
        ],
        "target": false,
        "start": 0,
        "end": 18,
        "viSpans": [
          [
            0,
            20
          ]
        ]
      },
      {
        "en": "can place considerable pressure on",
        "vi": [
          "có thể gây áp lực đáng kể lên"
        ],
        "target": true,
        "start": 19,
        "end": 53,
        "viSpans": [
          [
            21,
            50
          ]
        ]
      },
      {
        "en": "personal relationships.",
        "vi": [
          "các mối quan hệ cá nhân."
        ],
        "target": false,
        "start": 54,
        "end": 77,
        "viSpans": [
          [
            51,
            75
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Writing",
    "family": "f15",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t8",
    "level": 2,
    "unit": 1,
    "title": "Thừa nhận",
    "vi": "Phải thừa nhận rằng xe điện vẫn còn đắt đối với nhiều hộ gia đình.",
    "en": "Admittedly, electric cars remain costly for many households.",
    "frames": [
      "Admittedly"
    ],
    "chunks": [
      {
        "en": "Admittedly,",
        "vi": [
          "Phải thừa nhận rằng"
        ],
        "target": true,
        "start": 0,
        "end": 11,
        "viSpans": [
          [
            0,
            19
          ]
        ]
      },
      {
        "en": "electric cars remain costly",
        "vi": [
          "xe điện vẫn còn đắt"
        ],
        "target": false,
        "start": 12,
        "end": 39,
        "viSpans": [
          [
            20,
            39
          ]
        ]
      },
      {
        "en": "for many households.",
        "vi": [
          "đối với nhiều hộ gia đình."
        ],
        "target": false,
        "start": 40,
        "end": 60,
        "viSpans": [
          [
            40,
            66
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f21",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t9",
    "level": 2,
    "unit": 1,
    "title": "So sánh",
    "vi": "Trước đây, các gia đình thường ăn cùng nhau, trong khi ngày nay nhiều người ăn một mình.",
    "en": "In the past, families tended to eat together, whereas nowadays many people eat alone.",
    "frames": [
      "In the past",
      "whereas nowadays"
    ],
    "chunks": [
      {
        "en": "In the past,",
        "vi": [
          "Trước đây,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            10
          ]
        ]
      },
      {
        "en": "families tended to eat together,",
        "vi": [
          "các gia đình thường ăn cùng nhau,"
        ],
        "target": false,
        "start": 13,
        "end": 45,
        "viSpans": [
          [
            11,
            44
          ]
        ]
      },
      {
        "en": "whereas nowadays",
        "vi": [
          "trong khi ngày nay"
        ],
        "target": true,
        "start": 46,
        "end": 62,
        "viSpans": [
          [
            45,
            63
          ]
        ]
      },
      {
        "en": "many people eat alone.",
        "vi": [
          "nhiều người ăn một mình."
        ],
        "target": false,
        "start": 63,
        "end": 85,
        "viSpans": [
          [
            64,
            88
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Writing",
    "family": "f19",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t10",
    "level": 2,
    "unit": 1,
    "title": "Lựa chọn",
    "vi": "Nếu phải chọn, có lẽ tôi sẽ sống ở một thị trấn nhỏ hơn là một thành phố lớn.",
    "en": "If I had to choose, I'd probably live in a small town rather than a big city.",
    "frames": [
      "If I had to choose, I'd probably"
    ],
    "chunks": [
      {
        "en": "If I had to choose, I'd probably",
        "vi": [
          "Nếu phải chọn, có lẽ tôi sẽ"
        ],
        "target": true,
        "start": 0,
        "end": 32,
        "viSpans": [
          [
            0,
            27
          ]
        ]
      },
      {
        "en": "live in a small town",
        "vi": [
          "sống ở một thị trấn nhỏ"
        ],
        "target": false,
        "start": 33,
        "end": 53,
        "viSpans": [
          [
            28,
            51
          ]
        ]
      },
      {
        "en": "rather than a big city.",
        "vi": [
          "hơn là một thành phố lớn."
        ],
        "target": false,
        "start": 54,
        "end": 77,
        "viSpans": [
          [
            52,
            77
          ]
        ]
      }
    ],
    "topic": "city",
    "register": "Speaking",
    "family": "f25",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t11",
    "level": 2,
    "unit": 2,
    "title": "Quan điểm",
    "vi": "Theo quan điểm của tôi, tập thể dục thường xuyên nên là một phần của cuộc sống hằng ngày.",
    "en": "From my perspective, regular exercise should be part of daily life.",
    "frames": [
      "From my perspective"
    ],
    "chunks": [
      {
        "en": "From my perspective,",
        "vi": [
          "Theo quan điểm của tôi,"
        ],
        "target": true,
        "start": 0,
        "end": 20,
        "viSpans": [
          [
            0,
            23
          ]
        ]
      },
      {
        "en": "regular exercise",
        "vi": [
          "tập thể dục thường xuyên"
        ],
        "target": false,
        "start": 21,
        "end": 37,
        "viSpans": [
          [
            24,
            48
          ]
        ]
      },
      {
        "en": "should be part of daily life.",
        "vi": [
          "nên là một phần của cuộc sống hằng ngày."
        ],
        "target": false,
        "start": 38,
        "end": 67,
        "viSpans": [
          [
            49,
            89
          ]
        ]
      }
    ],
    "topic": "health",
    "register": "Writing",
    "family": "f1",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t12",
    "level": 2,
    "unit": 2,
    "title": "Quan điểm",
    "vi": "Tôi cho rằng các thành phố nên đầu tư nhiều hơn vào năng lượng tái tạo.",
    "en": "I would argue that cities should invest more in renewable energy.",
    "frames": [
      "I would argue that"
    ],
    "chunks": [
      {
        "en": "I would argue that",
        "vi": [
          "Tôi cho rằng"
        ],
        "target": true,
        "start": 0,
        "end": 18,
        "viSpans": [
          [
            0,
            12
          ]
        ]
      },
      {
        "en": "cities should invest more",
        "vi": [
          "các thành phố nên đầu tư nhiều hơn"
        ],
        "target": false,
        "start": 19,
        "end": 44,
        "viSpans": [
          [
            13,
            47
          ]
        ]
      },
      {
        "en": "in renewable energy.",
        "vi": [
          "vào năng lượng tái tạo."
        ],
        "target": false,
        "start": 45,
        "end": 65,
        "viSpans": [
          [
            48,
            71
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f2",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t13",
    "level": 2,
    "unit": 2,
    "title": "Quan điểm",
    "vi": "Ở mức độ lớn, tôi đồng ý rằng giờ làm việc linh hoạt có thể cải thiện sự hài lòng trong công việc.",
    "en": "To a large extent, I agree that flexible working hours can improve job satisfaction.",
    "frames": [
      "To a large extent, I agree that"
    ],
    "chunks": [
      {
        "en": "To a large extent, I agree that",
        "vi": [
          "Ở mức độ lớn, tôi đồng ý rằng"
        ],
        "target": true,
        "start": 0,
        "end": 31,
        "viSpans": [
          [
            0,
            29
          ]
        ]
      },
      {
        "en": "flexible working hours",
        "vi": [
          "giờ làm việc linh hoạt"
        ],
        "target": false,
        "start": 32,
        "end": 54,
        "viSpans": [
          [
            30,
            52
          ]
        ]
      },
      {
        "en": "can improve job satisfaction.",
        "vi": [
          "có thể cải thiện sự hài lòng trong công việc."
        ],
        "target": false,
        "start": 55,
        "end": 84,
        "viSpans": [
          [
            53,
            98
          ]
        ]
      }
    ],
    "topic": "work",
    "register": "Writing",
    "family": "f3",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t14",
    "level": 2,
    "unit": 2,
    "title": "Lý do",
    "vi": "Điều này chủ yếu là do lớp học nhỏ cho phép giáo viên quan tâm đến học sinh nhiều hơn.",
    "en": "This is primarily because small classes allow teachers to give students more attention.",
    "frames": [
      "This is primarily because"
    ],
    "chunks": [
      {
        "en": "This is primarily because",
        "vi": [
          "Điều này chủ yếu là do"
        ],
        "target": true,
        "start": 0,
        "end": 25,
        "viSpans": [
          [
            0,
            22
          ]
        ]
      },
      {
        "en": "small classes allow teachers to",
        "vi": [
          "lớp học nhỏ cho phép giáo viên"
        ],
        "target": false,
        "start": 26,
        "end": 57,
        "viSpans": [
          [
            23,
            53
          ]
        ]
      },
      {
        "en": "give students more attention.",
        "vi": [
          "quan tâm đến học sinh nhiều hơn."
        ],
        "target": false,
        "start": 58,
        "end": 87,
        "viSpans": [
          [
            54,
            86
          ]
        ]
      }
    ],
    "topic": "education",
    "register": "Writing",
    "family": "f5",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t15",
    "level": 2,
    "unit": 2,
    "title": "Thêm ý",
    "vi": "Một điều cần cân nhắc nữa là làn đường xe đạp an toàn có thể giảm ùn tắc giao thông.",
    "en": "Another important consideration is that safe cycle lanes can reduce traffic congestion.",
    "frames": [
      "Another important consideration is that"
    ],
    "chunks": [
      {
        "en": "Another important consideration is that",
        "vi": [
          "Một điều cần cân nhắc nữa là"
        ],
        "target": true,
        "start": 0,
        "end": 39,
        "viSpans": [
          [
            0,
            28
          ]
        ]
      },
      {
        "en": "safe cycle lanes",
        "vi": [
          "làn đường xe đạp an toàn"
        ],
        "target": false,
        "start": 40,
        "end": 56,
        "viSpans": [
          [
            29,
            53
          ]
        ]
      },
      {
        "en": "can reduce traffic congestion.",
        "vi": [
          "có thể giảm ùn tắc giao thông."
        ],
        "target": false,
        "start": 57,
        "end": 87,
        "viSpans": [
          [
            54,
            84
          ]
        ]
      }
    ],
    "topic": "city",
    "register": "Writing",
    "family": "f6",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t16",
    "level": 2,
    "unit": 3,
    "title": "Thêm ý",
    "vi": "Hơn nữa, những bữa ăn chung mang đến cho các gia đình thời gian trò chuyện.",
    "en": "Furthermore, shared meals give families time to talk.",
    "frames": [
      "Furthermore"
    ],
    "chunks": [
      {
        "en": "Furthermore,",
        "vi": [
          "Hơn nữa,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            8
          ]
        ]
      },
      {
        "en": "shared meals give families",
        "vi": [
          "những bữa ăn chung mang đến cho các gia đình"
        ],
        "target": false,
        "start": 13,
        "end": 39,
        "viSpans": [
          [
            9,
            53
          ]
        ]
      },
      {
        "en": "time to talk.",
        "vi": [
          "thời gian trò chuyện."
        ],
        "target": false,
        "start": 40,
        "end": 53,
        "viSpans": [
          [
            54,
            75
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Writing",
    "family": "f7",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t17",
    "level": 2,
    "unit": 3,
    "title": "Ví dụ",
    "vi": "Ví dụ, du khách có thể tìm hiểu các truyền thống địa phương bằng cách ghé thăm những bảo tàng nhỏ.",
    "en": "For example, travellers can learn about local traditions by visiting small museums.",
    "frames": [
      "For example"
    ],
    "chunks": [
      {
        "en": "For example,",
        "vi": [
          "Ví dụ,"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            6
          ]
        ]
      },
      {
        "en": "travellers can learn about local traditions",
        "vi": [
          "du khách có thể tìm hiểu các truyền thống địa phương"
        ],
        "target": false,
        "start": 13,
        "end": 56,
        "viSpans": [
          [
            7,
            59
          ]
        ]
      },
      {
        "en": "by visiting small museums.",
        "vi": [
          "bằng cách ghé thăm những bảo tàng nhỏ."
        ],
        "target": false,
        "start": 57,
        "end": 83,
        "viSpans": [
          [
            60,
            98
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "f8",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t18",
    "level": 2,
    "unit": 3,
    "title": "Ví dụ",
    "vi": "Một ví dụ điển hình là các bể bơi cộng đồng, giúp việc tập luyện dễ tiếp cận hơn.",
    "en": "A good example of this is community swimming pools, which make exercise more accessible.",
    "frames": [
      "A good example of this is"
    ],
    "chunks": [
      {
        "en": "A good example of this is",
        "vi": [
          "Một ví dụ điển hình là"
        ],
        "target": true,
        "start": 0,
        "end": 25,
        "viSpans": [
          [
            0,
            22
          ]
        ]
      },
      {
        "en": "community swimming pools,",
        "vi": [
          "các bể bơi cộng đồng,"
        ],
        "target": false,
        "start": 26,
        "end": 51,
        "viSpans": [
          [
            23,
            44
          ]
        ]
      },
      {
        "en": "which make exercise more accessible.",
        "vi": [
          "giúp việc tập luyện dễ tiếp cận hơn."
        ],
        "target": false,
        "start": 52,
        "end": 88,
        "viSpans": [
          [
            45,
            81
          ]
        ]
      }
    ],
    "topic": "health",
    "register": "Writing",
    "family": "f9",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t19",
    "level": 2,
    "unit": 3,
    "title": "Ví dụ",
    "vi": "Lấy các lễ hội địa phương làm ví dụ: chúng thu hút du khách và hỗ trợ những doanh nghiệp nhỏ.",
    "en": "Take local festivals, for example: they attract visitors and support small businesses.",
    "frames": [
      "Take",
      "for example"
    ],
    "chunks": [
      {
        "en": "Take local festivals, for example:",
        "vi": [
          "Lấy các lễ hội địa phương làm ví dụ:"
        ],
        "target": true,
        "start": 0,
        "end": 34,
        "viSpans": [
          [
            0,
            36
          ]
        ]
      },
      {
        "en": "they attract visitors",
        "vi": [
          "chúng thu hút du khách"
        ],
        "target": false,
        "start": 35,
        "end": 56,
        "viSpans": [
          [
            37,
            59
          ]
        ]
      },
      {
        "en": "and support small businesses.",
        "vi": [
          "và hỗ trợ những doanh nghiệp nhỏ."
        ],
        "target": false,
        "start": 57,
        "end": 86,
        "viSpans": [
          [
            60,
            93
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "f10",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t20",
    "level": 2,
    "unit": 3,
    "title": "Kết quả",
    "vi": "Kết quả là các hộ gia đình có thể giảm rác thải bằng cách tái sử dụng đồ dùng hằng ngày.",
    "en": "As a result, households can reduce waste by reusing everyday items.",
    "frames": [
      "As a result"
    ],
    "chunks": [
      {
        "en": "As a result,",
        "vi": [
          "Kết quả là"
        ],
        "target": true,
        "start": 0,
        "end": 12,
        "viSpans": [
          [
            0,
            10
          ]
        ]
      },
      {
        "en": "households can reduce waste",
        "vi": [
          "các hộ gia đình có thể giảm rác thải"
        ],
        "target": false,
        "start": 13,
        "end": 40,
        "viSpans": [
          [
            11,
            47
          ]
        ]
      },
      {
        "en": "by reusing everyday items.",
        "vi": [
          "bằng cách tái sử dụng đồ dùng hằng ngày."
        ],
        "target": false,
        "start": 41,
        "end": 67,
        "viSpans": [
          [
            48,
            88
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f11",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t21",
    "level": 2,
    "unit": 4,
    "title": "Kết quả",
    "vi": "Do đó, người đi làm dành ít thời gian hơn để chờ xe buýt.",
    "en": "Consequently, commuters spend less time waiting for buses.",
    "frames": [
      "Consequently"
    ],
    "chunks": [
      {
        "en": "Consequently,",
        "vi": [
          "Do đó,"
        ],
        "target": true,
        "start": 0,
        "end": 13,
        "viSpans": [
          [
            0,
            6
          ]
        ]
      },
      {
        "en": "commuters spend less time",
        "vi": [
          "người đi làm dành ít thời gian hơn"
        ],
        "target": false,
        "start": 14,
        "end": 39,
        "viSpans": [
          [
            7,
            41
          ]
        ]
      },
      {
        "en": "waiting for buses.",
        "vi": [
          "để chờ xe buýt."
        ],
        "target": false,
        "start": 40,
        "end": 58,
        "viSpans": [
          [
            42,
            57
          ]
        ]
      }
    ],
    "topic": "city",
    "register": "Writing",
    "family": "f12",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t22",
    "level": 2,
    "unit": 4,
    "title": "So sánh",
    "vi": "So với trước đây, du khách có nhiều cơ hội hơn để khám phá những nơi xa xôi.",
    "en": "Compared with the past, travellers have more opportunities to explore distant places.",
    "frames": [
      "Compared with the past"
    ],
    "chunks": [
      {
        "en": "Compared with the past,",
        "vi": [
          "So với trước đây,"
        ],
        "target": true,
        "start": 0,
        "end": 23,
        "viSpans": [
          [
            0,
            17
          ]
        ]
      },
      {
        "en": "travellers have more opportunities",
        "vi": [
          "du khách có nhiều cơ hội hơn"
        ],
        "target": false,
        "start": 24,
        "end": 58,
        "viSpans": [
          [
            18,
            46
          ]
        ]
      },
      {
        "en": "to explore distant places.",
        "vi": [
          "để khám phá những nơi xa xôi."
        ],
        "target": false,
        "start": 59,
        "end": 85,
        "viSpans": [
          [
            47,
            76
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "f20",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t23",
    "level": 2,
    "unit": 4,
    "title": "Phản biện",
    "vi": "Tuy nhiên, lập luận này bỏ qua thực tế là không gian xanh có thể cải thiện chất lượng không khí đô thị.",
    "en": "Nevertheless, this argument overlooks the fact that green spaces can improve urban air quality.",
    "frames": [
      "Nevertheless, this argument overlooks the fact that"
    ],
    "chunks": [
      {
        "en": "Nevertheless, this argument overlooks the fact that",
        "vi": [
          "Tuy nhiên, lập luận này bỏ qua thực tế là"
        ],
        "target": true,
        "start": 0,
        "end": 51,
        "viSpans": [
          [
            0,
            41
          ]
        ]
      },
      {
        "en": "green spaces",
        "vi": [
          "không gian xanh"
        ],
        "target": false,
        "start": 52,
        "end": 64,
        "viSpans": [
          [
            42,
            57
          ]
        ]
      },
      {
        "en": "can improve urban air quality.",
        "vi": [
          "có thể cải thiện chất lượng không khí đô thị."
        ],
        "target": false,
        "start": 65,
        "end": 95,
        "viSpans": [
          [
            58,
            103
          ]
        ]
      }
    ],
    "topic": "environment",
    "register": "Writing",
    "family": "f22",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t24",
    "level": 2,
    "unit": 4,
    "title": "Chưa chắc chắn",
    "vi": "Tôi không hoàn toàn chắc, nhưng tôi đoán những bữa ăn chung giúp các gia đình gắn bó.",
    "en": "I'm not entirely sure, but I'd imagine that shared meals help families stay close.",
    "frames": [
      "I'm not entirely sure, but I'd imagine that"
    ],
    "chunks": [
      {
        "en": "I'm not entirely sure, but I'd imagine that",
        "vi": [
          "Tôi không hoàn toàn chắc, nhưng tôi đoán"
        ],
        "target": true,
        "start": 0,
        "end": 43,
        "viSpans": [
          [
            0,
            40
          ]
        ]
      },
      {
        "en": "shared meals",
        "vi": [
          "những bữa ăn chung"
        ],
        "target": false,
        "start": 44,
        "end": 56,
        "viSpans": [
          [
            41,
            59
          ]
        ]
      },
      {
        "en": "help families stay close.",
        "vi": [
          "giúp các gia đình gắn bó."
        ],
        "target": false,
        "start": 57,
        "end": 82,
        "viSpans": [
          [
            60,
            85
          ]
        ]
      }
    ],
    "topic": "family",
    "register": "Speaking",
    "family": "f23",
    "sentenceType": "complex",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "v2-t25",
    "level": 2,
    "unit": 4,
    "title": "Tùy trường hợp",
    "vi": "Điều đó thực sự còn tùy tình huống, nhưng tôi thích du lịch một mình khi tôi cần nghỉ ngơi.",
    "en": "It really depends on the situation, but I enjoy travelling alone when I need a break.",
    "frames": [
      "It really depends on the situation"
    ],
    "chunks": [
      {
        "en": "It really depends on the situation,",
        "vi": [
          "Điều đó thực sự còn tùy tình huống,"
        ],
        "target": true,
        "start": 0,
        "end": 35,
        "viSpans": [
          [
            0,
            35
          ]
        ]
      },
      {
        "en": "but I enjoy travelling alone",
        "vi": [
          "nhưng tôi thích du lịch một mình"
        ],
        "target": false,
        "start": 36,
        "end": 64,
        "viSpans": [
          [
            36,
            68
          ]
        ]
      },
      {
        "en": "when I need a break.",
        "vi": [
          "khi tôi cần nghỉ ngơi."
        ],
        "target": false,
        "start": 65,
        "end": 85,
        "viSpans": [
          [
            69,
            91
          ]
        ]
      }
    ],
    "topic": "travel",
    "register": "Speaking",
    "family": "f24",
    "sentenceType": "simple",
    "difficulty": 2,
    "source": "Biên soạn cho FrameLab, theo spec người dùng",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null
  },
  {
    "id": "p1",
    "level": 3,
    "unit": 0,
    "title": "Giáo dục trực tuyến",
    "vi": "Một trong những lợi ích chính của giáo dục trực tuyến là khả năng tiếp cận. Điều này chủ yếu là vì sinh viên có thể tham gia các lớp học bất kể họ sống ở đâu. Ví dụ, sinh viên sống ở vùng nông thôn có thể tham gia các khóa học do các trường đại học lớn cung cấp. Kết quả là nhiều người hơn có thể tiếp cận nền giáo dục chất lượng cao.",
    "en": "One of the main benefits of online education is its accessibility. This is primarily because students can attend classes regardless of where they live. For example, students living in rural areas can take courses offered by major universities. As a result, more people can gain access to high-quality education.",
    "frames": [
      "One of the main benefits",
      "This is primarily because",
      "For example",
      "As a result"
    ],
    "topic": "education",
    "register": "Writing",
    "family": "p1",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": [
      {
        "en": "One of the main benefits of online education is its accessibility.",
        "vi": [
          "Một trong những lợi ích chính của giáo dục trực tuyến là khả năng tiếp cận."
        ],
        "target": true,
        "start": 0,
        "end": 66,
        "viSpans": [
          [
            0,
            75
          ]
        ]
      },
      {
        "en": "This is primarily because students can attend classes regardless of where they live.",
        "vi": [
          "Điều này chủ yếu là vì sinh viên có thể tham gia các lớp học bất kể họ sống ở đâu."
        ],
        "target": true,
        "start": 67,
        "end": 151,
        "viSpans": [
          [
            76,
            158
          ]
        ]
      },
      {
        "en": "For example, students living in rural areas can take courses offered by major universities.",
        "vi": [
          "Ví dụ, sinh viên sống ở vùng nông thôn có thể tham gia các khóa học do các trường đại học lớn cung cấp."
        ],
        "target": true,
        "start": 152,
        "end": 243,
        "viSpans": [
          [
            159,
            262
          ]
        ]
      },
      {
        "en": "As a result, more people can gain access to high-quality education.",
        "vi": [
          "Kết quả là nhiều người hơn có thể tiếp cận nền giáo dục chất lượng cao."
        ],
        "target": true,
        "start": 244,
        "end": 311,
        "viSpans": [
          [
            263,
            334
          ]
        ]
      }
    ],
    "sentences": [
      {
        "en": "One of the main benefits of online education is its accessibility.",
        "vi": "Một trong những lợi ích chính của giáo dục trực tuyến là khả năng tiếp cận."
      },
      {
        "en": "This is primarily because students can attend classes regardless of where they live.",
        "vi": "Điều này chủ yếu là vì sinh viên có thể tham gia các lớp học bất kể họ sống ở đâu."
      },
      {
        "en": "For example, students living in rural areas can take courses offered by major universities.",
        "vi": "Ví dụ, sinh viên sống ở vùng nông thôn có thể tham gia các khóa học do các trường đại học lớn cung cấp."
      },
      {
        "en": "As a result, more people can gain access to high-quality education.",
        "vi": "Kết quả là nhiều người hơn có thể tiếp cận nền giáo dục chất lượng cao."
      }
    ]
  },
  {
    "id": "v2-p2",
    "level": 3,
    "unit": 1,
    "title": "Không gian xanh đô thị",
    "vi": "Một trong những lợi ích chính của không gian xanh đô thị là sức khỏe cộng đồng tốt hơn. Điều này chủ yếu là vì công viên cung cấp cho cư dân nơi tập thể dục và thư giãn. Ví dụ, các gia đình có thể đi dạo cùng nhau sau giờ làm. Kết quả là mọi người có thể trở nên năng động hơn và cảm thấy bớt căng thẳng.",
    "en": "One of the main benefits of urban green spaces is better public health. This is primarily because parks give residents places to exercise and relax. For example, families can go for walks together after work. As a result, people may become more active and feel less stressed.",
    "frames": [
      "One of the main benefits",
      "This is primarily because",
      "For example",
      "As a result"
    ],
    "topic": "city",
    "register": "Writing",
    "family": "p2",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": [
      {
        "en": "One of the main benefits of urban green spaces is better public health.",
        "vi": [
          "Một trong những lợi ích chính của không gian xanh đô thị là sức khỏe cộng đồng tốt hơn."
        ],
        "target": true,
        "start": 0,
        "end": 71,
        "viSpans": [
          [
            0,
            87
          ]
        ]
      },
      {
        "en": "This is primarily because parks give residents places to exercise and relax.",
        "vi": [
          "Điều này chủ yếu là vì công viên cung cấp cho cư dân nơi tập thể dục và thư giãn."
        ],
        "target": true,
        "start": 72,
        "end": 148,
        "viSpans": [
          [
            88,
            169
          ]
        ]
      },
      {
        "en": "For example, families can go for walks together after work.",
        "vi": [
          "Ví dụ, các gia đình có thể đi dạo cùng nhau sau giờ làm."
        ],
        "target": true,
        "start": 149,
        "end": 208,
        "viSpans": [
          [
            170,
            226
          ]
        ]
      },
      {
        "en": "As a result, people may become more active and feel less stressed.",
        "vi": [
          "Kết quả là mọi người có thể trở nên năng động hơn và cảm thấy bớt căng thẳng."
        ],
        "target": true,
        "start": 209,
        "end": 275,
        "viSpans": [
          [
            227,
            304
          ]
        ]
      }
    ],
    "sentences": [
      {
        "en": "One of the main benefits of urban green spaces is better public health.",
        "vi": "Một trong những lợi ích chính của không gian xanh đô thị là sức khỏe cộng đồng tốt hơn."
      },
      {
        "en": "This is primarily because parks give residents places to exercise and relax.",
        "vi": "Điều này chủ yếu là vì công viên cung cấp cho cư dân nơi tập thể dục và thư giãn."
      },
      {
        "en": "For example, families can go for walks together after work.",
        "vi": "Ví dụ, các gia đình có thể đi dạo cùng nhau sau giờ làm."
      },
      {
        "en": "As a result, people may become more active and feel less stressed.",
        "vi": "Kết quả là mọi người có thể trở nên năng động hơn và cảm thấy bớt căng thẳng."
      }
    ]
  },
  {
    "id": "v2-p3",
    "level": 3,
    "unit": 2,
    "title": "Du học có đáng đầu tư?",
    "vi": "Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn. Tuy nhiên, lập luận này bỏ qua thực tế rằng học bổng có thể giảm chi phí cho một số sinh viên. Nói cách khác, rào cản tài chính không cao như nhau đối với mọi ứng viên.",
    "en": "Admittedly, studying abroad can be expensive, particularly for families on modest incomes. Nevertheless, this argument overlooks the fact that scholarships may reduce the cost for some students. In other words, the financial barrier is not equally high for every applicant.",
    "frames": [
      "Admittedly",
      "Nevertheless, this argument overlooks the fact that",
      "In other words"
    ],
    "topic": "travel",
    "register": "Writing",
    "family": "p3",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": [
      {
        "en": "Admittedly, studying abroad can be expensive, particularly for families on modest incomes.",
        "vi": [
          "Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn."
        ],
        "target": true,
        "start": 0,
        "end": 90,
        "viSpans": [
          [
            0,
            91
          ]
        ]
      },
      {
        "en": "Nevertheless, this argument overlooks the fact that scholarships may reduce the cost for some students.",
        "vi": [
          "Tuy nhiên, lập luận này bỏ qua thực tế rằng học bổng có thể giảm chi phí cho một số sinh viên."
        ],
        "target": true,
        "start": 91,
        "end": 194,
        "viSpans": [
          [
            92,
            186
          ]
        ]
      },
      {
        "en": "In other words, the financial barrier is not equally high for every applicant.",
        "vi": [
          "Nói cách khác, rào cản tài chính không cao như nhau đối với mọi ứng viên."
        ],
        "target": true,
        "start": 195,
        "end": 273,
        "viSpans": [
          [
            187,
            260
          ]
        ]
      }
    ],
    "sentences": [
      {
        "en": "Admittedly, studying abroad can be expensive, particularly for families on modest incomes.",
        "vi": "Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn."
      },
      {
        "en": "Nevertheless, this argument overlooks the fact that scholarships may reduce the cost for some students.",
        "vi": "Tuy nhiên, lập luận này bỏ qua thực tế rằng học bổng có thể giảm chi phí cho một số sinh viên."
      },
      {
        "en": "In other words, the financial barrier is not equally high for every applicant.",
        "vi": "Nói cách khác, rào cản tài chính không cao như nhau đối với mọi ứng viên."
      }
    ]
  },
  {
    "id": "v2-sp1",
    "level": 4,
    "unit": 0,
    "title": "Part 1 · Cooking",
    "vi": "Có, thực ra là tôi thích. Điều đó thực sự còn tùy tâm trạng của tôi, nhưng tôi thường thấy nấu ăn khá thư giãn sau một ngày dài. Ví dụ, cuối tuần trước tôi đã nấu một nồi súp lớn cho bạn bè, và công sức bỏ ra hoàn toàn xứng đáng.",
    "en": "Yes, I do, actually. It really depends on my mood, but I usually find it quite relaxing after a long day. For example, last weekend I made a big pot of soup for my friends, and it was totally worth the effort.",
    "frames": [
      "Yes, I do",
      "It really depends on",
      "For example"
    ],
    "prompt": "Do you enjoy cooking?",
    "topic": "health",
    "register": "Speaking",
    "family": "sp1",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": []
  },
  {
    "id": "sp2",
    "level": 4,
    "unit": 1,
    "title": "Part 1 · Work",
    "vi": "Tôi hiện đang làm thực tập sinh hỗ trợ quản lý sản phẩm. Tôi thực sự thích công việc này, chủ yếu vì nó cho tôi cơ hội học hỏi từ những đồng nghiệp giàu kinh nghiệm. Ví dụ, tôi hỗ trợ theo dõi tiến độ kiểm thử và trao đổi với các nhóm khác nhau.",
    "en": "I am currently working as a product management intern. I really enjoy this job, mainly because it gives me opportunities to learn from experienced colleagues. For example, I help track testing progress and communicate with different teams.",
    "frames": [
      "I am currently",
      "mainly because",
      "For example"
    ],
    "prompt": "Do you work or are you a student?",
    "topic": "travel",
    "register": "Speaking",
    "family": "sp2",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": []
  },
  {
    "id": "sp3",
    "level": 4,
    "unit": 2,
    "title": "Part 3 · Education",
    "vi": "Tôi nghĩ công nghệ đã cải thiện giáo dục ở mức độ lớn. Lý do chính là nó cho phép sinh viên tiếp cận thông tin dễ dàng hơn. Ví dụ, sinh viên hiện có thể tham gia các khóa học trực tuyến từ các trường đại học ở quốc gia khác. Kết quả là họ có nhiều cơ hội học tập hơn. Tuy nhiên, việc phụ thuộc quá nhiều vào công nghệ cũng có thể làm giảm sự tương tác trực tiếp.",
    "en": "I think technology has improved education to a large extent. The main reason is that it allows students to access information more easily. For example, students can now take online courses from universities in other countries. As a result, they have more learning opportunities. However, excessive dependence on technology can also reduce face-to-face interaction.",
    "frames": [
      "to a large extent",
      "The main reason is that",
      "For example",
      "As a result",
      "However"
    ],
    "prompt": "Has technology improved education?",
    "topic": "travel",
    "register": "Speaking",
    "family": "sp3",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": []
  },
  {
    "id": "sp4",
    "level": 4,
    "unit": 3,
    "title": "Part 2 · A memorable trip",
    "vi": "Tôi muốn nói về một chuyến đi Đà Nẵng mà tôi đã thực hiện cùng vài người bạn thân khoảng hai năm trước. Nếu tôi nhớ không nhầm, chúng tôi ở đó ba ngày sau khi hoàn thành một học kỳ bận rộn. Chúng tôi chọn thành phố này vì muốn dành thời gian bên biển và thử các món ăn địa phương. Điều tôi nhớ rõ nhất là chúng tôi dậy sớm để ngắm bình minh trên bãi biển. Đường phố vẫn yên tĩnh và không khí trong lành. Chúng tôi ngồi trên cát, nói chuyện và chụp một vài bức ảnh. Một điều khác đáng nhắc đến là một người bạn đã tìm thấy một nhà hàng nhỏ do một gia đình địa phương điều hành. Món ăn vừa ngon vừa có giá phải chăng, nên chúng tôi quay lại đó vào tối hôm sau. Điều khiến chuyến đi đặc biệt đáng nhớ là chúng tôi đã có cơ hội thực sự trò chuyện mà không bị công việc hay việc học làm phiền. Tôi nhớ mình cảm thấy rất vui và thư giãn. Nhìn lại, tôi nghĩ chuyến đi đã giúp tôi nhận ra tầm quan trọng của việc dành thời gian cho những người mình quan tâm. Tôi rất muốn quay lại đó cùng nhóm bạn này.",
    "en": "I'd like to talk about a trip to Da Nang that I took with a few close friends about two years ago. If I remember correctly, we stayed there for three days after finishing a busy semester. We chose the city because we wanted to spend time by the sea and try the local food. What I remember most clearly is getting up early to watch the sunrise on the beach. The streets were still quiet and the air was fresh. We sat on the sand, talked and took a few photos. Another thing worth mentioning is that a friend found a small restaurant run by a local family. The food was both delicious and affordable, so we went back the following evening. What made the trip particularly memorable was that we had the chance to really talk without being distracted by work or study. I remember feeling really happy and relaxed. Looking back, I think the trip helped me realise the importance of spending time with people I care about. I would love to return there with the same group of friends.",
    "frames": [
      "I'd like to talk about",
      "If I remember correctly",
      "What I remember most clearly",
      "Another thing worth mentioning",
      "What made the trip particularly memorable",
      "Looking back"
    ],
    "prompt": "Describe a memorable trip. Say where you went, who you went with, what you did and why it was memorable.",
    "topic": "travel",
    "register": "Speaking",
    "family": "sp4",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": []
  },
  {
    "id": "w1",
    "level": 5,
    "unit": 0,
    "title": "Task 2 · Education & work",
    "vi": "Một số người cho rằng các trường đại học nên tập trung vào kỹ năng thực tiễn thay vì kiến thức lý thuyết. Mặc dù lý thuyết tạo nền tảng quan trọng, tôi cho rằng các trường đại học nên kết hợp cả hai. Cách tiếp cận này có thể giúp sinh viên chuẩn bị cho công việc và thích ứng với những thay đổi trong tương lai.\n\nMột trong những lý do chính là kỹ năng thực tiễn giúp sinh viên chuyển kiến thức thành hành động. Điều này chủ yếu là vì nhà tuyển dụng thường cần những người có thể giải quyết các vấn đề thực tế và làm việc hiệu quả với người khác. Ví dụ, sinh viên quản lý thông tin có thể học cách tổ chức dữ liệu trong lớp, nhưng một kỳ thực tập cho phép họ áp dụng kiến thức đó vào một dự án thực tế. Kết quả là họ có thể bước vào môi trường làm việc với sự tự tin lớn hơn và hiểu rõ hơn trách nhiệm hằng ngày của mình. Những dự án như vậy cũng khuyến khích sinh viên đặt câu hỏi, phản hồi góp ý và giải thích quyết định của mình cho người khác, những khả năng khó phát triển chỉ bằng việc ghi nhớ thông tin.\n\nMột yếu tố quan trọng khác là kiến thức lý thuyết vẫn cần thiết cho sự phát triển lâu dài. Các công cụ và quy trình có thể thay đổi nhanh chóng, nên chỉ biết thực hiện một nhiệm vụ cụ thể có thể là chưa đủ. Ví dụ, một sinh viên hiểu các nguyên tắc phân tích dữ liệu có thể học phần mềm mới dễ dàng hơn người chỉ ghi nhớ một bộ hướng dẫn. Phải thừa nhận rằng việc học lý thuyết đôi khi có thể có vẻ xa rời công việc thực tế. Tuy nhiên, hạn chế này có thể được giải quyết bằng cách kết nối các bài giảng với nghiên cứu tình huống và các dự án có hướng dẫn.\n\nTóm lại, tôi tin rằng các trường đại học nên kết hợp đào tạo thực tiễn với nền tảng lý thuyết vững chắc. Kỹ năng thực tiễn hỗ trợ sinh viên trong công việc đầu tiên, trong khi lý thuyết giúp họ tiếp tục học hỏi và thích ứng trong suốt sự nghiệp.",
    "en": "Some people believe that universities should focus on practical skills rather than theoretical knowledge. Although theory provides an important foundation, I would argue that universities should combine both. This approach can help students prepare for employment and adapt to future changes.\n\nOne of the main reasons is that practical skills help students turn knowledge into action. This is primarily because employers often need people who can solve real problems and work effectively with others. For example, information management students may learn how to organise data in class, but an internship allows them to apply that knowledge to a real project. As a result, they can enter the workplace with greater confidence and a clearer understanding of their daily responsibilities. Such projects also encourage students to ask questions, respond to feedback and explain their decisions to others, abilities that are difficult to develop simply by memorising information.\n\nAnother important consideration is that theoretical knowledge remains necessary for long-term development. Tools and procedures can change rapidly, so knowing how to perform one particular task may not be enough. For example, a student who understands the principles of data analysis can learn new software more easily than someone who has only memorised a set of instructions. Admittedly, studying theory can sometimes seem disconnected from practical work. However, this limitation can be addressed by connecting lectures with case studies and guided projects.\n\nIn conclusion, I believe that universities should combine practical training with a strong theoretical foundation. Practical skills support students in their first jobs, while theory helps them continue learning and adapting throughout their careers.",
    "frames": [
      "I would argue that",
      "One of the main reasons is that",
      "This is primarily because",
      "For example",
      "As a result",
      "Another important consideration is that",
      "Admittedly",
      "In conclusion"
    ],
    "prompt": "Universities should focus on practical skills rather than theoretical knowledge. To what extent do you agree or disagree?",
    "minWords": 250,
    "topic": "education",
    "register": "Writing",
    "family": "w1",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": [],
    "sections": [
      {
        "en": "Some people believe that universities should focus on practical skills rather than theoretical knowledge. Although theory provides an important foundation, I would argue that universities should combine both. This approach can help students prepare for employment and adapt to future changes.",
        "vi": "Một số người cho rằng các trường đại học nên tập trung vào kỹ năng thực tiễn thay vì kiến thức lý thuyết. Mặc dù lý thuyết tạo nền tảng quan trọng, tôi cho rằng các trường đại học nên kết hợp cả hai. Cách tiếp cận này có thể giúp sinh viên chuẩn bị cho công việc và thích ứng với những thay đổi trong tương lai.",
        "label": "Mở bài"
      },
      {
        "en": "One of the main reasons is that practical skills help students turn knowledge into action. This is primarily because employers often need people who can solve real problems and work effectively with others. For example, information management students may learn how to organise data in class, but an internship allows them to apply that knowledge to a real project. As a result, they can enter the workplace with greater confidence and a clearer understanding of their daily responsibilities. Such projects also encourage students to ask questions, respond to feedback and explain their decisions to others, abilities that are difficult to develop simply by memorising information.",
        "vi": "Một trong những lý do chính là kỹ năng thực tiễn giúp sinh viên chuyển kiến thức thành hành động. Điều này chủ yếu là vì nhà tuyển dụng thường cần những người có thể giải quyết các vấn đề thực tế và làm việc hiệu quả với người khác. Ví dụ, sinh viên quản lý thông tin có thể học cách tổ chức dữ liệu trong lớp, nhưng một kỳ thực tập cho phép họ áp dụng kiến thức đó vào một dự án thực tế. Kết quả là họ có thể bước vào môi trường làm việc với sự tự tin lớn hơn và hiểu rõ hơn trách nhiệm hằng ngày của mình. Những dự án như vậy cũng khuyến khích sinh viên đặt câu hỏi, phản hồi góp ý và giải thích quyết định của mình cho người khác, những khả năng khó phát triển chỉ bằng việc ghi nhớ thông tin.",
        "label": "Thân bài 1"
      },
      {
        "en": "Another important consideration is that theoretical knowledge remains necessary for long-term development. Tools and procedures can change rapidly, so knowing how to perform one particular task may not be enough. For example, a student who understands the principles of data analysis can learn new software more easily than someone who has only memorised a set of instructions. Admittedly, studying theory can sometimes seem disconnected from practical work. However, this limitation can be addressed by connecting lectures with case studies and guided projects.",
        "vi": "Một yếu tố quan trọng khác là kiến thức lý thuyết vẫn cần thiết cho sự phát triển lâu dài. Các công cụ và quy trình có thể thay đổi nhanh chóng, nên chỉ biết thực hiện một nhiệm vụ cụ thể có thể là chưa đủ. Ví dụ, một sinh viên hiểu các nguyên tắc phân tích dữ liệu có thể học phần mềm mới dễ dàng hơn người chỉ ghi nhớ một bộ hướng dẫn. Phải thừa nhận rằng việc học lý thuyết đôi khi có thể có vẻ xa rời công việc thực tế. Tuy nhiên, hạn chế này có thể được giải quyết bằng cách kết nối các bài giảng với nghiên cứu tình huống và các dự án có hướng dẫn.",
        "label": "Thân bài 2"
      },
      {
        "en": "In conclusion, I believe that universities should combine practical training with a strong theoretical foundation. Practical skills support students in their first jobs, while theory helps them continue learning and adapting throughout their careers.",
        "vi": "Tóm lại, tôi tin rằng các trường đại học nên kết hợp đào tạo thực tiễn với nền tảng lý thuyết vững chắc. Kỹ năng thực tiễn hỗ trợ sinh viên trong công việc đầu tiên, trong khi lý thuyết giúp họ tiếp tục học hỏi và thích ứng trong suốt sự nghiệp.",
        "label": "Kết luận"
      }
    ]
  },
  {
    "id": "w2",
    "level": 5,
    "unit": 1,
    "title": "Task 1 · Thay đổi số liệu",
    "prompt": "Bảng luyện tập giả định: tỷ lệ người đi làm bằng xe buýt / ô tô tại một thành phố. Năm 2000: 20% / 60%; 2010: 30% / 50%; 2020: 40% / 40%. Tóm tắt và so sánh các đặc điểm chính.",
    "vi": "Bảng cho biết thông tin về tỷ lệ người đi làm bằng xe buýt và ô tô tại một thành phố trong các năm 2000, 2010 và 2020.\n\nNhìn chung, tỷ lệ người dùng xe buýt tăng đều, trong khi tỷ lệ đi bằng ô tô giảm. Ô tô phổ biến hơn vào đầu giai đoạn, nhưng hai hình thức có tỷ lệ bằng nhau vào năm 2020.\n\nNăm 2000, xe buýt chiếm 20% số người đi làm, so với 60% đi bằng ô tô. Điều này có nghĩa là tỷ lệ dùng ô tô cao gấp ba lần tỷ lệ dùng xe buýt. Đến năm 2010, tỷ lệ dùng xe buýt đã tăng lên 30%, trong khi tỷ lệ dùng ô tô giảm xuống 50%. Khoảng cách vì vậy thu hẹp từ 40 xuống 20 điểm phần trăm.\n\nTrong thập kỷ tiếp theo, tỷ lệ dùng xe buýt tăng thêm 10 điểm phần trăm và đạt 40%. Ngược lại, tỷ lệ dùng ô tô giảm xuống 40%. Trong toàn bộ giai đoạn, tỷ lệ dùng xe buýt tăng gấp đôi, còn tỷ lệ dùng ô tô giảm 20 điểm phần trăm.",
    "en": "The table provides information about the percentages of commuters travelling by bus and car in a city in 2000, 2010 and 2020.\n\nOverall, the proportion of bus users increased steadily, whereas the percentage travelling by car declined. Cars were more popular at the beginning of the period, but the two modes had equal shares by 2020.\n\nIn 2000, buses accounted for 20% of commuters, compared with 60% for cars. This means that the figure for cars was three times the figure for buses. By 2010, the bus share had risen to 30%, while the car share had fallen to 50%. The gap therefore narrowed from 40 to 20 percentage points.\n\nOver the following decade, the bus share increased by another 10 percentage points to reach 40%. By contrast, the proportion of car users fell to 40%. Across the whole period, the bus share doubled, while the car share decreased by 20 percentage points.",
    "frames": [
      "The table provides information about",
      "Overall",
      "whereas",
      "compared with",
      "By contrast"
    ],
    "minWords": 150,
    "topic": "education",
    "register": "Writing",
    "family": "w2",
    "sentenceType": "paragraph",
    "difficulty": 3,
    "source": "Biên soạn cho FrameLab",
    "reviewStatus": "Chưa được chuyên gia IELTS duyệt",
    "reviewer": null,
    "reviewedAt": null,
    "chunks": [],
    "sections": [
      {
        "en": "The table provides information about the percentages of commuters travelling by bus and car in a city in 2000, 2010 and 2020.",
        "vi": "Bảng cho biết thông tin về tỷ lệ người đi làm bằng xe buýt và ô tô tại một thành phố trong các năm 2000, 2010 và 2020.",
        "label": "Mở bài"
      },
      {
        "en": "Overall, the proportion of bus users increased steadily, whereas the percentage travelling by car declined. Cars were more popular at the beginning of the period, but the two modes had equal shares by 2020.",
        "vi": "Nhìn chung, tỷ lệ người dùng xe buýt tăng đều, trong khi tỷ lệ đi bằng ô tô giảm. Ô tô phổ biến hơn vào đầu giai đoạn, nhưng hai hình thức có tỷ lệ bằng nhau vào năm 2020.",
        "label": "Tổng quan"
      },
      {
        "en": "In 2000, buses accounted for 20% of commuters, compared with 60% for cars. This means that the figure for cars was three times the figure for buses. By 2010, the bus share had risen to 30%, while the car share had fallen to 50%. The gap therefore narrowed from 40 to 20 percentage points.",
        "vi": "Năm 2000, xe buýt chiếm 20% số người đi làm, so với 60% đi bằng ô tô. Điều này có nghĩa là tỷ lệ dùng ô tô cao gấp ba lần tỷ lệ dùng xe buýt. Đến năm 2010, tỷ lệ dùng xe buýt đã tăng lên 30%, trong khi tỷ lệ dùng ô tô giảm xuống 50%. Khoảng cách vì vậy thu hẹp từ 40 xuống 20 điểm phần trăm.",
        "label": "Chi tiết 1"
      },
      {
        "en": "Over the following decade, the bus share increased by another 10 percentage points to reach 40%. By contrast, the proportion of car users fell to 40%. Across the whole period, the bus share doubled, while the car share decreased by 20 percentage points.",
        "vi": "Trong thập kỷ tiếp theo, tỷ lệ dùng xe buýt tăng thêm 10 điểm phần trăm và đạt 40%. Ngược lại, tỷ lệ dùng ô tô giảm xuống 40%. Trong toàn bộ giai đoạn, tỷ lệ dùng xe buýt tăng gấp đôi, còn tỷ lệ dùng ô tô giảm 20 điểm phần trăm.",
        "label": "Chi tiết 2"
      }
    ]
  }
];
export const levels = [{"title": "Câu xương sống", "desc": "25 câu · 5 bài nhỏ", "label": "Gõ theo, rồi tự nhớ"}, {"title": "Đổi chủ đề", "desc": "25 câu · 5 bài nhỏ", "label": "Dùng mẫu trong ngữ cảnh mới"}, {"title": "Ghép thành đoạn", "desc": "3 đoạn · 3 chủ đề", "label": "Kết nối ý tưởng"}, {"title": "Speaking hoàn chỉnh", "desc": "4 bài · Part 1, 2 & 3", "label": "Nói tự nhiên hơn"}, {"title": "Writing hoàn chỉnh", "desc": "2 bài · Task 1 & Task 2", "label": "Từ từng phần đến cả bài"}];

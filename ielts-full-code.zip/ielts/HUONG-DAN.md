# FrameLab — bản xuất đầy đủ mã nguồn

## Nguồn bản xuất

Mã nguồn bản demo: https://frame-lab-ielts.nthehdang.chatgpt.site
Commit: `9fdebc8fd7522e520cd5807abe431a380f39283a`.
Giao diện, logic luyện, backend và MCP được giữ nguyên từ commit này. Gói bổ sung hướng dẫn chạy, cấu hình database local, tài liệu và dữ liệu bài bổ sung tại thời điểm xuất.

## Chạy trên Windows

Giải nén để có thư mục `D:\cá nhân\ielts`. Cần Node.js >=22.13.0 và pnpm 11.25.0 theo `package.json`. Mở PowerShell:

```powershell
cd 'D:\cá nhân\ielts'
pnpm install --frozen-lockfile
pnpm exec wrangler d1 migrations apply DB --local --config wrangler.local.json --persist-to .wrangler/state
pnpm exec wrangler d1 execute DB --local --config wrangler.local.json --persist-to .wrangler/state --file data/online-seed.sql
pnpm dev
```

Mở địa chỉ local được terminal thông báo (mặc định http://localhost:5173). Truy cập `/signin-with-chatgpt?return_to=/` trên cùng địa chỉ local để dùng tài khoản mô phỏng phục vụ phát triển. Trên máy khác, lần cài đầu cần Internet tải dependencies. Chưa kiểm thử trực tiếp trên Windows; mã nguồn đã build thành công ở môi trường Linux của demo.

Nếu PowerShell chưa có pnpm, cài đúng phiên bản được ghi trong trường `packageManager` của `package.json`. Không dùng `install:ci` trên PowerShell vì script đó dành cho môi trường Bash.

## Nội dung

- `app/`: giao diện, CSS, API lưu bài/phiên học, API kho bài và MCP.
- `components/`, `hooks/`: các thành phần giao diện và hỗ trợ nhập liệu.
- `lib/`: 59 bài cố định, chấm theo mẫu, ôn cách quãng, nguồn Internet và updater.
- `db/`, `drizzle/`: schema và migrations.
- `data/`: snapshot bài bổ sung và SQL nhập nội dung chung.
- `docs/`: đặc tả hiện hành, tài liệu gốc, hướng dẫn MCP, ngân hàng bài học.
- `spec.md`: đặc tả kèm bổ sung v1.3.
- `package.json`, `pnpm-lock.yaml`: phụ thuộc và phiên bản.

## Những phần cần cấu hình khi triển khai riêng

- Tiến độ cá nhân và tài khoản đang dùng trên demo không được sao chép. Local có database và người dùng thử riêng.
- Lịch 07:00 hằng ngày thuộc nền tảng Sites, không tự chuyển sang máy tính qua ZIP. Hướng dẫn updater nằm trong `lib/online.ts` và `docs/ky-thuat/MCP-va-cap-nhat.md`.
- OAuth MCP và xác thực dịch vụ do Sites quản lý. `/mcp` và `/api/content-update` dựa vào lớp xác thực này. Khi host ngoài Sites phải thêm lớp xác thực tương đương trước khi công khai các endpoint; chạy local nên giữ trên localhost.
- `.openai/hosting.json` giữ ID của Site gốc để thể hiện cấu hình demo. Không dùng ID này để triển khai một Site mới.
- Nguồn bên ngoài có thể không truy cập được; tại lần thiết lập, British Council trả HTTP 520 còn IELTS.org truy cập được.
- Không kèm node_modules, cache, token hay thông tin đăng nhập. Cài phụ thuộc bằng lệnh trên.

import {catalog,refreshSources} from '@/lib/online';
import {getChatGPTUser} from '@/app/chatgpt-auth';
export async function GET(){if(!await getChatGPTUser())return Response.json({error:'Vui lòng đăng nhập.'},{status:401});try{return Response.json(await catalog());}catch{return Response.json({error:'Chưa tải được kho bài. Hãy thử lại.'},{status:503});}}
export async function POST(req:Request){if(!await getChatGPTUser())return Response.json({error:'Vui lòng đăng nhập.'},{status:401});if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Invalid origin'},{status:403});try{return Response.json(await refreshSources());}catch{return Response.json({error:'Chưa kiểm tra được nguồn.'},{status:503});}}

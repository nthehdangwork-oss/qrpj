// Shared-content service endpoint uses Sites' private service-access boundary.
// MCP OAuth clients use /mcp; unattended tasks use this JSON-RPC endpoint.
export {POST,GET,DELETE} from '@/app/mcp/route';

import {getOnlineItem} from '@/lib/online';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {db,progress} from '@/lib/db';
import {items,COURSE_VERSION} from '@/lib/course';
import {grade} from '@/lib/grading';
import {targetFor,dateKey,unlocked,Stage} from '@/lib/learning';
export async function GET(){const u=await getChatGPTUser();if(!u)return Response.json({error:'Vui lòng đăng nhập lại để tải tiến độ.'},{status:401});try{return Response.json(await progress(u.userId));}catch(e){console.error(e);return Response.json({error:'Chưa tải được tiến độ. Hãy thử lại.'},{status:503});}}
export async function POST(req:Request){
 const u=await getChatGPTUser();if(!u)return Response.json({error:'Vui lòng đăng nhập lại để lưu bài.'},{status:401});
 if(req.headers.get('origin')&&req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Invalid origin'},{status:403});
 try{const b=await req.json() as {itemId:string;answer:string;id:string;stage:Stage;hinted:boolean;selfConfirmed:boolean;section?:number};const original=items.find(i=>i.id===b.itemId)||await getOnlineItem(b.itemId);const online=original?.id.startsWith('web-');
 if(!original||(online&&b.section!==undefined)||typeof b.answer!=='string'||!b.answer.trim()||b.answer.length>15000||typeof b.id!=='string'||!/^[-a-z0-9]{20,64}$/i.test(b.id)||!['A','B','C'].includes(b.stage)||((b.stage==='A')&&original.level!==1))return Response.json({error:'Bài làm không hợp lệ.'},{status:400});
 const payload=JSON.stringify([b.itemId,b.answer,b.stage,b.hinted===true,b.selfConfirmed===true,b.section??null]);
 const prev=await db().prepare('SELECT payload,result,xp FROM attempts WHERE id=? AND user_id=?').bind(b.id,u.userId).first<{payload:string;result:string;xp:number}>();
 if(prev){if(prev.payload!==payload)return Response.json({error:'Mã lượt học đã được sử dụng. Hãy kiểm tra lại.'},{status:409});return Response.json({...JSON.parse(prev.result),xp:prev.xp,progress:await progress(u.userId)});}
 const before=await progress(u.userId);if(!online&&!unlocked(before,original.level))return Response.json({error:'Hoàn thành level trước để mở bài này.'},{status:403});
 const item=online?original:targetFor({itemId:b.itemId,stage:b.stage,section:b.section});const result=grade(item,b.answer);
 const selfConfirmed=b.stage==='C'&&b.selfConfirmed===true&&result.canSelfConfirm;
 const correct=result.exact||selfConfirmed;const hinted=b.hinted===true||selfConfirmed||b.stage!=='C'||b.section!==undefined;const independent=correct&&!hinted;
 const xp=correct?(b.stage==='A'?2:independent?10:3):0;const now=Date.now(),day=dateKey(now);
 const feedback={...result,correct,xp,independent,selfConfirmed};
 // Atomic award: A can earn XP only once per user, item and local day.
 await db().prepare("INSERT OR IGNORE INTO attempts (id,user_id,item_id,correct,hinted,xp,created,day,stage,independent,self_confirmed,course_version,result,payload) SELECT ?,?,?,?,?,CASE WHEN ?='A' AND EXISTS(SELECT 1 FROM attempts WHERE user_id=? AND item_id=? AND day=? AND stage='A' AND correct=1) THEN 0 ELSE ? END,?,?,?,?,?,?,?,?").bind(b.id,u.userId,item.id,correct?1:0,hinted?1:0,b.stage,u.userId,item.id,day,xp,now,day,b.stage,independent?1:0,selfConfirmed?1:0,COURSE_VERSION,JSON.stringify(feedback),payload).run();
 const stored=await db().prepare('SELECT xp,result,payload FROM attempts WHERE id=? AND user_id=?').bind(b.id,u.userId).first<{xp:number;result:string;payload:string}>();
 if(!stored||stored.payload!==payload)return Response.json({error:'Mã lượt học bị trùng. Hãy thử lại.'},{status:409});return Response.json({...JSON.parse(stored.result),xp:stored.xp,progress:await progress(u.userId)});
 }catch(e){console.error(e);return Response.json({error:'Chưa lưu được bài. Câu bạn gõ vẫn được giữ; hãy thử lại.'},{status:503});}
}

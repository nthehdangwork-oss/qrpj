import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'FrameLab · Luyện mẫu câu IELTS',description:'Dịch chủ động, lặp lại có chủ đích. Từ một câu đến một bài hoàn chỉnh.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="vi"><body>{children}</body></html>}

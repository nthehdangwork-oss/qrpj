# FrameLab — Đặc tả sản phẩm và triển khai v1.2

- Phiên bản: 1.2 — 06/10/2026.
- Cơ sở: bản `SPEC — Website luyện mẫu câu IELTS bằng Active Recall (v1.1)` do người dùng cung cấp trong `Pasted text.txt`.
- Sản phẩm: FrameLab, website luyện mẫu câu Việt → Anh.
- Phạm vi: nâng cấp website đang có; giữ lịch sử và XP, không tạo website thay thế.
- Ngôn ngữ: giao diện và giải thích tiếng Việt; bài làm tiếng Anh.

## 1. Mục tiêu và nguyên tắc

Giúp người học đi từ **gõ theo câu có mẫu → nhớ lại câu → dùng cùng cấu trúc trong chủ đề mới → ghép đoạn → viết bài hoàn chỉnh**.

Người học tự tạo câu bằng bàn phím; trắc nghiệm và sắp xếp từ không phải hoạt động chính. Hệ thống hỗ trợ luyện Writing và Speaking, không cam kết band và không quy đổi XP thành điểm IELTS.

Ba nguyên tắc:

1. **Hỗ trợ giảm dần:** chữ mờ là lớp gợi ý, không phải nội dung đã nhập.
2. **Nối chữ với nghĩa:** mỗi cụm tiếng Anh có ánh xạ tiếng Việt được biên soạn sẵn; không đoán ánh xạ cho câu khác mẫu.
3. **Phân biệt luyện và nhớ:** gõ theo mẫu, xem gợi ý, tự xác nhận và tự nhớ phải được ghi nhận riêng.

## 2. Những điểm làm rõ từ v1.1

| Điểm cần làm rõ | Quyết định v1.2 | Lý do |
|---|---|---|
| 25 cấu trúc nhưng chỉ 10 câu chuyển chủ đề | Level 2 có 25 câu, mỗi nhóm cấu trúc có câu ở ít nhất hai chủ đề | Đủ độ bao phủ để luyện chuyển ngữ cảnh |
| Level 2 gọi là A nhưng chỉ hiện khung | Dùng tên B cho Level 2; A luôn là mẫu đầy đủ | Thống nhất cách tính XP và hỗ trợ |
| Cần hai lượt C nhưng Level 2 chỉ mô tả một lượt | Level 2: B → C → C′ | Đủ hai lượt tự nhớ để mở khóa |
| Mọi lượt có hỗ trợ đều bị thêm lại | A/B đúng đi tiếp theo lịch đã có; chỉ thêm lại khi sai hoặc C có hỗ trợ | Tránh hàng đợi tăng vô hạn vì A/B vốn luôn có hỗ trợ |
| “Đã nhớ” có thể bị hiểu là nhớ lâu | Hiển thị “đã tự nhớ” khi đủ 2 lượt; thêm chỉ số ôn đúng qua nhiều ngày | Không đồng nhất hai lần đúng trong buổi với ghi nhớ dài hạn |
| Hai lựa chọn mẫu mờ một phần | Bản này chọn **chỉ hiện cụm cấu trúc** | Đơn giản, nhất quán; chưa triển khai kiểu chữ cái đầu |
| Tracking theo dấu chấm có thể sai với viết tắt | Dùng các câu song ngữ được biên soạn sẵn và tiền tố khớp mẫu | Không dùng số dấu chấm để đoán người học đang viết câu nào |
| Một câu có thể đúng nhưng khác mẫu | Dùng nhãn “chưa khớp mẫu”, không kết luận “chưa dịch” hoặc “sai ngữ pháp” | Phân biệt đối chiếu chuỗi với đánh giá ngôn ngữ |
| Nhãn “phong cách 7.0+” chưa có đánh giá độc lập | Nhãn “Writing”, “Speaking”; không gắn band cho câu | Không tạo ấn tượng đã được giám khảo xác nhận |
| Yêu cầu người duyệt chuyên môn chưa được đáp ứng | Lưu `reviewStatus`, `reviewer`, `reviewedAt`; hiện “Chưa được chuyên gia IELTS duyệt” | Không tạo tên hoặc ngày duyệt giả |
| Có ví dụ Level 1 ngắn hơn 10 từ | Câu ngắn được phép nếu tự nhiên; mục tiêu 8–24 từ | Ưu tiên câu dễ hiểu, không thêm từ chỉ để đủ số lượng |
| Chỉ lưu điểm, chưa lưu chỗ học | Lưu hàng đợi, vị trí, giai đoạn, bản nháp và phản hồi | Cho phép tiếp tục sau khi tải lại |

## 3. Lộ trình và nội dung

### 3.1. Quy mô bản triển khai

| Level | Nội dung | Số bài tập | Cách luyện mặc định |
|---|---|---:|---|
| 1 | Câu xương sống | 25 | A → B → C → C′, chia 5 nhóm |
| 2 | Đổi chủ đề | 25 | B → C → C′, chia 5 nhóm |
| 3 | Ghép thành đoạn | 3 | C → C′; có lựa chọn luyện từng câu trước |
| 4 | Speaking Part 1, 2, 3 | 4 | C → C′ |
| 5 | Academic Writing Task 1, Task 2 | 2 | C → C′; có lựa chọn luyện từng đoạn trước |
| **Tổng** | | **59** | |

“Bài tập” là một câu, một đoạn hoặc một bài hoàn chỉnh. “Bài nhỏ” là nhóm các bài tập trong một buổi; hai khái niệm không dùng lẫn nhau khi tính tiến độ.

### 3.2. Level 1 — Câu xương sống

- Dùng 25 câu trong phụ lục A của tài liệu v1.1, phân thành 5 nhóm.
- Một nhóm gồm 5 câu, luyện theo các vòng: A của cả nhóm, B của cả nhóm, C của cả nhóm, C′ theo thứ tự xoay vòng.
- Mỗi câu có chức năng, cấu trúc, văn phong, chủ đề và cụm song ngữ.
- Khi lặp lại C′, người học phải gõ lại từ ô trống.

### 3.3. Level 2 — Đổi chủ đề

- Mỗi cấu trúc được sử dụng lại trong ít nhất một chủ đề khác Level 1.
- Bao gồm các câu chuyển chủ đề trong phụ lục B, có điều chỉnh để luyện lại cấu trúc đầy đủ.
- Ví dụ “online banking removes the need…” được mở rộng thành câu chứa “One of the main reasons is that…” để tiếp tục luyện cấu trúc chính.
- B hiện khung; C và C′ không hiện tiếng Anh trước khi người học yêu cầu.
- Biến thể chia động từ theo chủ ngữ, như `plays` / `play`, được biên soạn thành yêu cầu cụ thể của từng câu; không coi một dạng là đúng cho mọi chủ ngữ.

### 3.4. Level 3 — Ghép đoạn

Ba chủ đề: giáo dục trực tuyến, không gian xanh đô thị, du học.

- Luyện quan hệ giữa ý chính, giải thích, ví dụ, kết quả và nhượng bộ.
- Có thể bắt đầu bằng cả đoạn hoặc chọn “Luyện từng câu trước”.
- Luyện từng câu được ghi là có hỗ trợ; không mở khóa bằng các câu thành phần.
- Sau các câu thành phần là hai lượt viết cả đoạn.
- Ánh xạ câu Việt–Anh được khai báo trước; khi bài khác mẫu, không tự đoán câu tương ứng.

### 3.5. Level 4 — Speaking

- Hai bài Part 1, một bài Part 2 và một bài Part 3.
- Bản mẫu phục vụ tập diễn đạt, không phải bài để học thuộc và áp vào mọi cue card.
- Có câu hỏi tiếng Anh, nội dung tiếng Việt và bài tham khảo.
- Sau khi viết, người học được nhắc đọc thành tiếng và thay chi tiết bằng trải nghiệm của mình.
- Nghe mẫu sử dụng giọng đọc trình duyệt khi có hỗ trợ.
- Chưa thu âm, phân tích phát âm hoặc chấm fluency.

### 3.6. Level 5 — Writing

- Task 1 sử dụng bảng số liệu minh họa được nêu ngay trong đề; không trình bày như dữ liệu nghiên cứu thật.
- Task 1 luyện mở bài, overview và các đoạn mô tả; mục tiêu tối thiểu 150 từ.
- Task 2 luyện mở bài, hai đoạn thân bài và kết luận; mục tiêu tối thiểu 250 từ.
- Có lựa chọn luyện từng đoạn rồi viết cả bài.
- Số từ tối thiểu áp dụng cho bài hoàn chỉnh, không áp cho từng đoạn thành phần.
- Không coi việc có đủ các từ nối là đủ lập luận hoặc đủ band.
- Giữ đề Task 2 hiện có về kỹ năng thực tiễn và kiến thức lý thuyết; các đề mới phải xác định đúng loại câu hỏi trước khi xây khung.

## 4. Mẫu mờ và thao tác nhập

### 4.1. Các giai đoạn

| Giai đoạn | Nội dung được nhìn thấy | Nhớ độc lập | XP khi đúng | Tính mục tiêu ngày |
|---|---|---|---:|---|
| A | Cả câu tiếng Anh dưới dạng chữ mờ | Không | 2, chỉ lần đúng đầu tiên của câu trong ngày | Không |
| B | Chỉ các cụm cấu trúc; nội dung còn lại tự viết | Không | 3 | Có |
| C, không gợi ý | Ô trống | Có | 10 | Có |
| C, có gợi ý hoặc tự xác nhận | Khung hoặc đáp án sau thao tác yêu cầu | Không | 3 | Có |
| Luyện một phần bài dài | Có hỗ trợ | Không | 3 | Có |
| Sai/chưa khớp, chưa xác nhận | Phản hồi và đáp án sau kiểm tra | Không | 0 | Không |

### 4.2. Quy tắc nhập

- Giá trị thật của ô nhập luôn là phần người học gõ.
- Lớp mờ không tham gia form submission, không được đọc lặp bởi trình đọc màn hình và không chọn để copy qua thao tác thông thường.
- Không có chức năng nhấn Tab để điền mẫu.
- Chặn paste và kéo thả văn bản ở Level 1–2; hướng dẫn người học tự gõ.
- Đây là hỗ trợ thói quen học, không phải cơ chế chống gian lận tuyệt đối.
- Tắt spellcheck, autocorrect, autocomplete và tự viết hoa bằng thuộc tính trình duyệt hỗ trợ.
- Không kiểm tra từ khi đang nhập bằng IME.
- Chỉ đánh dấu từ sau khi kết thúc bằng khoảng trắng hoặc dấu câu.
- Khi một từ sai làm mất căn chỉnh, đánh dấu từ đầu tiên chưa khớp; không tô sai cả chuỗi phía sau.
- Không ngăn người học tiếp tục nhập hoặc sửa tại vị trí con trỏ.
- Khi tiền tố không còn khớp mẫu, phần gợi ý tiếp theo tạm ẩn để không đặt chữ mờ vào vị trí sai.
- Mẫu mờ và chữ đã gõ dùng cùng font, cỡ chữ, khoảng cách, padding và cách xuống dòng. Chữ đã gõ được nhấn rõ nhưng không đổi độ rộng ký tự.
- Chữ mờ dùng độ tương phản tối thiểu 3:1; lỗi có gạch chân dạng sóng và thông báo bằng chữ.

## 5. Ánh xạ và tracking song ngữ

### 5.1. Mô hình dữ liệu

Mỗi cụm có:

- `en`: nội dung tiếng Anh nguyên văn.
- `start`, `end`: vị trí ký tự của cụm trong câu Anh.
- `vi`: một hoặc nhiều đoạn tiếng Việt.
- `viSpans`: các khoảng ký tự tương ứng trong câu Việt.
- `target`: cụm có chứa cấu trúc mục tiêu hay không.

Tiếng Việt được hiển thị theo thứ tự câu gốc. Không sắp lại tiếng Việt theo thứ tự tiếng Anh.

Ví dụ cần hỗ trợ:

| Cụm Anh | Cụm Việt |
|---|---|
| Compared with the past | So với trước đây |
| today's students | học sinh ngày nay |
| have far easier access to | dễ tiếp cận … hơn nhiều |
| information | thông tin |

Hai đoạn “dễ tiếp cận” và “hơn nhiều” cùng thuộc một cụm, dù nằm ở hai vị trí.

### 5.2. Kiểm tra dữ liệu bắt buộc

- Các cụm tiếng Anh ghép lại thành đúng câu tham khảo.
- Không bỏ sót hoặc gán hai lần một từ tiếng Việt.
- Mỗi khoảng ký tự phải khớp nội dung nguồn.
- Level 1–2 có khoảng 3–6 cụm theo nghĩa; không tự chia từng từ.
- Dữ liệu của Level 3 ánh xạ theo câu đã biên soạn.

### 5.3. Hành vi

- A/B bật tracking mặc định; C tắt mặc định.
- Có công tắc bật/tắt; việc chỉ bật tracking ở C không tự hiển thị đáp án tiếng Anh.
- Cụm đang gõ được xác định từ **tiền tố đã khớp và vị trí con trỏ**.
- Cụm đang gõ có nền, độ đậm và viền dưới; cụm hoàn thành có dấu ✓.
- Chạm hoặc rê chuột lên cụm Việt làm nổi bật cụm tương ứng; dải đối chiếu tiếng Anh ở chế độ có hỗ trợ cho phép thao tác ngược lại.
- Dải đối chiếu B chỉ hiện cấu trúc; không lộ phần nội dung bị ẩn.
- Khi C khác mẫu, không tô sáng cụm theo suy đoán.
- Trình đọc màn hình nhận thông báo khi đổi cụm. Ở A có thể đọc cụm mẫu kế tiếp; ở B chỉ đọc cấu trúc được phép hiện, không đọc toàn bộ phần bị ẩn.

## 6. Đối chiếu và phản hồi

### 6.1. Chuẩn hóa

Chấp nhận khác biệt không làm đổi nội dung được hỗ trợ rõ ràng:
- Hoa/thường, khoảng trắng, dấu câu.
- Viết tắt phổ biến như `I'm` / `I am`, `I'd` / `I would` trong ngữ cảnh các câu mẫu này.
- Một số cách viết Anh–Anh/Anh–Mỹ: behaviour/behavior, travelling/traveling, prioritise/prioritize, v.v.

Không dùng độ giống chuỗi hoặc việc “có đủ từ khóa” làm bằng chứng câu đúng nghĩa.

### 6.2. A/B

- Yêu cầu khớp mẫu sau chuẩn hóa.
- Không cho tự xác nhận câu khác mẫu để vượt bước A/B.
- Mục tiêu là làm quen với câu và khung đang luyện.

### 6.3. C và bài dài

Ba kết quả:
1. Khớp mẫu: ghi nhận lượt đúng.
2. Thiếu khung: chỉ rõ những cấu trúc chưa khớp.
3. Đủ khung nhưng khác mẫu: đề nghị đối chiếu nghĩa và ngữ pháp.

Chức năng tự xác nhận:
- Chỉ có ở C khi đủ các cấu trúc, đủ độ dài tối thiểu hợp lý và đủ số từ nếu là bài Writing hoàn chỉnh.
- Hiển thị rõ đây là **người học tự xác nhận**, không phải AI xác nhận.
- Tính có hỗ trợ, không cộng lượt nhớ độc lập.
- Sau đó quay lại C trong hàng đợi.

Đối chiếu cụm sau khi kiểm tra dùng nhãn “khớp mẫu/chưa khớp”, không dùng nhãn “đã dịch/chưa dịch” cho câu khác mẫu.

## 7. Hàng đợi, ghi nhớ và ôn cách quãng

### 7.1. Hàng đợi trong buổi

- Lượt A/B đúng: đi tiếp theo kế hoạch, không thêm lại chỉ vì có hỗ trợ.
- Lượt C đúng độc lập: đi tiếp.
- Lượt C đúng có hỗ trợ: thêm một lượt C ở cuối.
- C chưa khớp và chọn luyện lại sau: thêm B rồi C.
- A/B chưa khớp và chọn luyện lại sau: thêm lại bước đó.
- Có thể sửa tại chỗ; vì đã thấy đáp án, lượt sửa được ghi là có hỗ trợ.
- Không trừ mạng, không khóa luyện khi sai.
- Mỗi bài nhỏ gồm ít câu; lượt ôn giới hạn 10 bài tập đầu tiên trong danh sách ưu tiên.

### 7.2. Mức độ nhớ

| Trạng thái | Điều kiện |
|---|---|
| Chưa luyện | Chưa có lượt nào |
| Đang học | Đã có lượt nhưng chưa đủ 2 lượt C độc lập |
| Đã tự nhớ | Có ít nhất 2 lượt đúng C độc lập ở bài hoàn chỉnh |
| Ôn đúng qua nhiều ngày | Có lượt đúng độc lập ở ít nhất 2 ngày địa phương khác nhau |

“Đã tự nhớ” dùng để mở khóa học tiếp, không khẳng định nhớ dài hạn.

### 7.3. Mở khóa

- Level 1 mở sẵn.
- Level tiếp theo mở khi mọi bài của level trước đạt “đã tự nhớ”.
- Kiểm tra ở cả giao diện và API gửi bài.
- Lượt A/B, lượt từng phần, xem gợi ý và tự xác nhận không mở khóa thay cho C độc lập.

### 7.4. Lịch ôn

- Múi giờ: Asia/Bangkok (UTC+7).
- Số ngày có nhớ đúng độc lập quyết định khoảng ôn: 1, 3, 7, 14, 30 ngày.
- Đúng nhiều lần cùng ngày không tăng bậc khoảng ôn.
- Sai khiến bài đến hạn luyện lại.
- Lượt có hỗ trợ không nâng bậc nhớ và không kéo dài hạn ôn.
- Bài chưa đủ hai lượt độc lập luôn thuộc nhóm cần luyện.
- Hạn ôn được tính từ lịch sử lưu trên máy chủ, không phụ thuộc đồng hồ lưu trong localStorage.
- Cụm “ôn đúng qua nhiều ngày” không được đổi thành “đã thành thạo vĩnh viễn”.

## 8. Tiếp tục bài đang học và lưu dữ liệu

### 8.1. Nội dung lưu

Theo từng tài khoản:
- Hàng đợi và vị trí đang làm.
- Giai đoạn A/B/C, bài nhỏ, level, chế độ học/ôn.
- Câu đang nhập.
- Mức gợi ý và trạng thái tracking.
- Phản hồi vừa nhận.
- ID lượt gửi đang chờ và XP của buổi.
- Trạng thái buổi đã hoàn thành.

### 8.2. Tự lưu

- Tự lưu sau khoảng 650 ms ngừng thay đổi.
- Yêu cầu lưu được gửi nối tiếp để không ghi đè bởi phản hồi đến sai thứ tự.
- Giao diện phân biệt: chưa lưu thay đổi, đang lưu, đã lưu và lỗi.
- Rời trang khi còn thay đổi chưa lưu có cảnh báo của trình duyệt khi trình duyệt hỗ trợ.
- Không cam kết khôi phục ký tự chưa kịp gửi khi đóng trình duyệt đột ngột.
- Nếu hai cửa sổ cùng sửa, dùng số revision để phát hiện xung đột; không âm thầm ghi đè.
- Nếu phản hồi mạng thất lạc nhưng cùng trạng thái đã được lưu, retry được coi là thành công, không tạo xung đột giả.

### 8.3. Idempotency và lỗi

- Mỗi lượt luyện có ID duy nhất.
- Gửi lại cùng ID, cùng payload trả về kết quả đã lưu, không tạo XP mới.
- Cùng ID nhưng payload khác bị từ chối.
- Giới hạn XP của A được kiểm tra trong cùng thao tác ghi dữ liệu.
- Khi gửi hoặc lưu lỗi, giữ nguyên nội dung trong giao diện và cho thử lại.
- Không hiển thị “đã lưu” khi thao tác chưa thành công.
- Danh tính lấy từ xác thực máy chủ; không nhận user ID do trình duyệt tự khai báo.

### 8.4. Nâng cấp dữ liệu cũ

- Giữ nguyên bảng lượt luyện cũ, XP và lịch sử theo ngày.
- Thêm cột và bảng mới bằng migration bổ sung; không sửa migration đã chạy.
- Câu có nội dung thay đổi dùng ID mới, không gán kết quả nhớ câu cũ sang câu mới.
- Các bài dài giữ nguyên nội dung được giữ ID để tiếp tục dùng tiến độ cũ.
- Giao diện thông báo ngân hàng câu mới cần luyện lại; XP lịch sử vẫn còn.

## 9. Màn hình và tương tác

### Học bài
- Lộ trình 5 level, trạng thái mở khóa.
- Chọn nhóm bài nhỏ.
- Thanh A/B/C và tiến độ lượt trong buổi.
- Câu Việt có ánh xạ, ô nhập, tracking, gợi ý và kiểm tra.
- Phản hồi, đáp án, nghe mẫu khi trình duyệt hỗ trợ.
- Mục tiêu ngày và trạng thái lưu.

### Ôn tập
- Danh sách ôn dựa trên tiến độ thật.
- Ưu tiên bài cần ôn sớm.
- Khi không có bài, hiển thị trạng thái trống và nút quay lại bài đang học; không tạo bài “đến hạn” giả.

### Sổ mẫu câu
- Nhóm theo level; lọc Writing/Speaking.
- Tìm theo câu, ý nghĩa hoặc chức năng.
- Câu song ngữ, cấu trúc và nguồn nội dung.
- Biến thể mở rộng minh họa theo văn phong.
- Ghi rõ trạng thái duyệt chuyên môn.

### Hoàn thành
- XP của buổi, số bài tự nhớ.
- Học tiếp hoặc làm lại.
- Nhắc quay lại ôn, không khẳng định đạt band.

## 10. Nội dung và quy trình duyệt

### Tiêu chuẩn

- Phủ ít nhất 8 nhóm chủ đề: giáo dục, công nghệ, môi trường, sức khỏe, công việc, đô thị, gia đình/xã hội, du lịch/văn hóa.
- Mỗi nhóm 5 câu Level 1 không quá 2 câu thuộc cùng chủ đề chính.
- Có câu đơn, câu phức, nhượng bộ, so sánh, quan hệ, điều kiện và dạng chuyển chủ đề.
- Writing dùng liên kết phù hợp văn viết; Speaking ưu tiên cách nói tự nhiên.
- Không xem từ khó, đảo ngữ hoặc nhiều từ nối là bằng chứng band cao.
- Không sao chép bài mẫu thương mại; nội dung là bài luyện tự biên soạn hoặc do người dùng cung cấp.
- Ví dụ thực tế chưa có nguồn được trình bày như ngữ cảnh luyện tập, không như số liệu đã kiểm chứng.

### Duyệt chuyên môn

Trường dữ liệu hiện có: chủ đề, văn phong, kiểu câu, độ khó, nguồn, trạng thái duyệt, người duyệt, ngày duyệt.

Trạng thái hiện tại: **chưa có chuyên gia IELTS duyệt độc lập**. `reviewer` và `reviewedAt` để trống. Người có chuyên môn cần rà soát ngữ pháp, tính tự nhiên, bản dịch, phân đoạn và độ phù hợp đề trước khi xem bộ nội dung là giáo trình đã được kiểm định.

Đây là hạng mục còn cần người duyệt; không mô tả là đã hoàn thành chỉ vì chương trình kiểm tra dữ liệu chạy thành công.

## 11. Mô hình kỹ thuật

- Giữ nền tảng web hiện có, không thay tên miền hoặc audience.
- Ngân hàng câu và ánh xạ được quản lý theo phiên bản cùng mã nguồn.
- D1 lưu lượt luyện và phiên học theo tài khoản.
- `attempts`: giữ trường cũ, bổ sung stage, independent, self_confirmed, course_version, result, payload.
- `learning_sessions`: user_id, state, revision, updated.
- Lịch ôn, tổng XP, chuỗi ngày và mức độ nhớ được suy ra từ lịch sử chuẩn.
- Không dùng localStorage làm nguồn sự thật cho điểm và tiến độ.
- API chính: đọc tiến độ, gửi lượt luyện, lưu phiên học.
- Công cụ đọc tiến độ cho trình duyệt hỗ trợ WebMCP được giữ lại; không làm phụ thuộc của luồng học.

## 12. Khả năng tiếp cận và thiết bị

- Hỗ trợ màn hình nhỏ, bàn phím và thao tác chạm.
- Có label ô nhập, trạng thái focus và thông báo lỗi bằng chữ.
- Ctrl/Cmd + Enter kiểm tra hoặc chuyển tiếp khi phù hợp.
- Không dùng màu sắc làm tín hiệu duy nhất.
- Không đọc lớp mẫu mờ hai lần bằng trình đọc màn hình.
- Tôn trọng giảm chuyển động của thiết bị.
- Nếu trình duyệt không có giọng đọc, không hiện nút nghe như một tính năng hoạt động.
- Tự sửa của bàn phím và cảnh báo rời trang phụ thuộc mức hỗ trợ của trình duyệt.

## 13. Tiêu chí nghiệm thu

| ID | Tình huống | Kết quả yêu cầu |
|---|---|---|
| AC01 | Mở Level 1 | A hiển thị mẫu đầy đủ nhưng giá trị nhập rỗng |
| AC02 | Chuyển sang B | Chỉ cấu trúc hiện mờ; không đọc lộ nội dung bị ẩn |
| AC03 | Chuyển sang C | Ô trống, tracking mặc định tắt |
| AC04 | Gõ qua cụm | Cụm Việt đúng được nhấn, kể cả ánh xạ không liên tục |
| AC05 | Viết khác mẫu | Không đoán tracking ở C |
| AC06 | Gõ từ chưa xong | Chưa đánh dấu lỗi |
| AC07 | Kết thúc từ sai | Gạch chân lỗi đầu tiên và có thông báo |
| AC08 | Dán hoặc kéo văn bản vào L1–2 | Không chèn văn bản, có hướng dẫn khi paste |
| AC09 | A đúng hai lần cùng ngày | Chỉ lần đúng đầu có 2 XP; không tính mục tiêu ngày |
| AC10 | A/B hoặc có gợi ý | Không tăng số lượt nhớ độc lập |
| AC11 | C sai và luyện lại sau | Thêm B rồi C |
| AC12 | C tự xác nhận | Tính có hỗ trợ, thêm lại C |
| AC13 | Hai lượt C đúng độc lập | Đạt tự nhớ; đủ cả level thì mở level tiếp |
| AC14 | Luyện cùng ngày nhiều lần | Không nhảy nhiều bậc lịch ôn |
| AC15 | Reload sau trạng thái đã lưu | Khôi phục câu, giai đoạn, hàng đợi và nháp |
| AC16 | Mất phản hồi và retry | Không cộng điểm trùng hoặc báo xung đột giả với cùng phiên |
| AC17 | Hai tab cùng lưu | Phát hiện revision xung đột |
| AC18 | Hai tài khoản | Không đọc hoặc ghi tiến độ của nhau |
| AC19 | Bài dài theo phần | Phần thành phần không tăng mastery cho bài hoàn chỉnh |
| AC20 | Bài Writing hoàn chỉnh | Kiểm tra đủ từ và khung; không tuyên bố chấm band |
| AC21 | Nội dung chưa duyệt | Không có tên giám khảo, ngày duyệt hoặc band giả |
| AC22 | Nội dung nâng cấp | Giữ XP cũ, không gán mastery cũ cho câu mới |
| AC23 | Màn hình nhỏ và phóng chữ | Lớp chữ mờ và phần nhập cùng cách xuống dòng |
| AC24 | Lỗi lưu | Giữ nội dung, cho retry, không báo đã lưu |

### Phạm vi kiểm tra trong lần triển khai này

- Kiểm tra TypeScript và bản dựng sản phẩm.
- Kiểm tra tự động 59 đáp án, số từ, khung và 177 cụm ánh xạ.
- Kiểm tra bao phủ 25 nhóm cấu trúc trên ít nhất hai chủ đề.
- Kiểm tra hàng đợi A/B/C, vòng lỗi B→C và bài dài theo phần.
- Kiểm tra chuẩn hóa, tiền tố, từ đang gõ và trường hợp cụm không liên tục.
- Kiểm tra SQLite với migration bổ sung, giới hạn XP A trong ngày, idempotency, tách tài khoản và mục tiêu ngày.
- Chưa có kiểm thử trực quan bằng trình duyệt hoặc thử trình đọc màn hình trong môi trường tác giả hiện tại; AC23 và trải nghiệm trợ năng cần xác nhận trên thiết bị thực.
- Chưa kiểm thử WebMCP trong trình duyệt có hỗ trợ; tính năng đọc tiến độ này không chặn việc học bình thường.

## 14. Ngoài phạm vi và hướng mở rộng

Chưa triển khai:
- Chấm ngữ pháp/ý nghĩa tự do bằng AI.
- Chấm band, phát âm, fluency hoặc ghi âm.
- Ánh xạ tự động cho câu khác mẫu.
- Kiểu mẫu mờ chữ cái đầu từng từ.
- Tự sinh vô hạn bài tập, bảng xếp hạng, thanh toán, lịch nhắc tự động.
- Quy trình phê duyệt chuyên gia đã hoàn thành.

Các tính năng này phải được mô tả là hướng mở rộng, không dùng nút giả hoặc thông báo như đã hoạt động.

## Phụ lục — Ngân hàng nội dung v1.2

Các bảng dưới đây là nội dung biên soạn, chưa phải bộ câu đã được giám khảo xác nhận band.

### Level 1 — Câu và cấu trúc

| # | Văn phong / chủ đề | Tiếng Việt | Tiếng Anh | Khung |
|---|---|---|---|---|
| 1 | Writing / city | Theo quan điểm của tôi, giao thông công cộng miễn phí sẽ mang lại lợi ích cho cả cư dân thành phố lẫn môi trường. | From my perspective, free public transport would benefit both city residents and the environment. | From my perspective |
| 2 | Writing / education | Tôi cho rằng các trường học nên ưu tiên tư duy phản biện hơn là học thuộc lòng. | I would argue that schools should prioritise critical thinking over rote memorisation. | I would argue that |
| 3 | Writing / technology | Ở mức độ lớn, tôi đồng ý rằng chính phủ nên quản lý nội dung mà trẻ em xem trên mạng. | To a large extent, I agree that governments should regulate the content that children see online. | To a large extent, I agree that |
| 4 | Writing / work | Một trong những lý do chính là làm việc từ xa loại bỏ nhu cầu đi lại dài mỗi ngày. | One of the main reasons is that remote work removes the need for long daily commutes. | One of the main reasons is that |
| 5 | Writing / health | Điều này chủ yếu là do những thói quen lành mạnh hình thành từ nhỏ thường kéo dài đến tuổi trưởng thành. | This is primarily because healthy habits formed in childhood tend to last into adulthood. | This is primarily because |
| 6 | Writing / environment | Một điều cần cân nhắc nữa là năng lượng tái tạo ngày càng rẻ hơn khi công nghệ được cải thiện. | Another important consideration is that renewable energy becomes cheaper as the technology improves. | Another important consideration is that |
| 7 | Writing / work | Hơn nữa, các nhà tuyển dụng ngày càng coi trọng những ứng viên có thể thích nghi nhanh với công cụ mới. | Furthermore, employers increasingly value candidates who can adapt quickly to new tools. | Furthermore |
| 8 | Writing / city | Ví dụ, nhiều thành phố đã khuyến khích người dân đạp xe nhiều hơn bằng cách xây dựng làn đường dành riêng cho xe đạp. | For example, many cities have encouraged more people to cycle by building dedicated bike lanes. | For example |
| 9 | Writing / education | Một ví dụ điển hình là các ứng dụng học ngôn ngữ, cho phép người dùng luyện tập chỉ vài phút mỗi ngày. | A good example of this is language-learning apps, which allow people to practise for just a few minutes a day. | A good example of this is |
| 10 | Writing / technology | Lấy mua sắm trực tuyến làm ví dụ: nó tiết kiệm thời gian nhưng cũng khuyến khích chi tiêu bốc đồng. | Take online shopping, for example: it saves time, yet it also encourages impulse spending. | Take / for example |
| 11 | Writing / health | Kết quả là bệnh nhân ở vùng xa có thể hỏi ý kiến chuyên gia mà không phải di chuyển hàng giờ. | As a result, patients in remote areas can consult specialists without travelling for hours. | As a result |
| 12 | Writing / education | Do đó, nhiều sinh viên tốt nghiệp khó tìm được việc làm phù hợp với trình độ của mình. | Consequently, many graduates struggle to find jobs that match their qualifications. | Consequently |
| 13 | Writing / health | Tập thể dục thường xuyên có thể tác động đáng kể đến cả sức khỏe thể chất lẫn tinh thần. | Regular exercise can have a significant impact on both physical health and mental well-being. | can have a significant impact on |
| 14 | Writing / technology | Công nghệ giúp con người làm việc hiệu quả hơn. | Technology enables people to work more efficiently. | enables people to |
| 15 | Writing / family | Chi phí nhà ở tăng cao có thể gây áp lực đáng kể lên các gia đình trẻ. | Rising housing costs can place considerable pressure on young families. | can place considerable pressure on |
| 16 | Writing / family | Hoạt động tình nguyện mang đến cho người trẻ cơ hội phát triển kỹ năng làm việc nhóm và lãnh đạo. | Volunteering provides young people with opportunities to develop teamwork and leadership skills. | provides young people with opportunities to |
| 17 | Writing / travel | Du lịch có thể đóng góp cho kinh tế địa phương bằng cách tạo việc làm và hỗ trợ các doanh nghiệp nhỏ. | Tourism can contribute to local economies by creating jobs and supporting small businesses. | can contribute to |
| 18 | Writing / education | Giáo dục đóng vai trò then chốt trong việc giảm bất bình đẳng giữa các nhóm xã hội khác nhau. | Education plays a crucial role in reducing inequality between different social groups. | plays a crucial role in |
| 19 | Writing / technology | Trước đây, mọi người thường đọc báo in, trong khi ngày nay hầu hết đọc tin tức trên điện thoại. | In the past, people tended to rely on printed newspapers, whereas nowadays most of them read the news on their phones. | In the past / whereas nowadays |
| 20 | Writing / education | So với trước đây, học sinh ngày nay dễ tiếp cận thông tin hơn nhiều. | Compared with the past, today's students have far easier access to information. | Compared with the past |
| 21 | Writing / travel | Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn. | Admittedly, studying abroad can be expensive, particularly for families on modest incomes. | Admittedly |
| 22 | Writing / education | Tuy nhiên, lập luận này bỏ qua thực tế là nhiều trường đại học cấp học bổng hào phóng. | Nevertheless, this argument overlooks the fact that many universities offer generous scholarships. | Nevertheless, this argument overlooks the fact that |
| 23 | Speaking / technology | Tôi không hoàn toàn chắc, nhưng tôi đoán hầu hết mọi người thích mua sắm trực tuyến vì nó tiện lợi. | I'm not entirely sure, but I'd imagine that most people prefer shopping online because it is convenient. | I'm not entirely sure, but I'd imagine that |
| 24 | Speaking / work | Điều đó thực sự còn tùy tình huống, nhưng nhìn chung tôi thích làm việc nhóm hơn. | It really depends on the situation, but I generally prefer working in a team. | It really depends on the situation |
| 25 | Speaking / travel | Nếu phải chọn, có lẽ tôi sẽ dành thời gian rảnh ở ngoài trời hơn là trong nhà. | If I had to choose, I'd probably spend my free time outdoors rather than indoors. | If I had to choose, I'd probably |

### Level 2 — Câu và cấu trúc

| # | Văn phong / chủ đề | Tiếng Việt | Tiếng Anh | Khung |
|---|---|---|---|---|
| 1 | Writing / education | Học trực tuyến giúp mọi người học tập linh hoạt hơn. | Online learning enables people to study more flexibly. | enables people to |
| 2 | Writing / technology | Một trong những lý do chính là ngân hàng trực tuyến loại bỏ nhu cầu xếp hàng tại chi nhánh. | One of the main reasons is that online banking removes the need for queuing at branches. | One of the main reasons is that |
| 3 | Writing / family | Thư viện công cộng đóng vai trò then chốt trong việc thúc đẩy học tập suốt đời. | Public libraries play a crucial role in promoting lifelong learning. | play a crucial role in |
| 4 | Writing / technology | Mạng xã hội có thể tác động đáng kể đến cách thanh thiếu niên nhìn nhận bản thân. | Social media can have a significant impact on how teenagers see themselves. | can have a significant impact on |
| 5 | Writing / work | Thực tập mang đến cho sinh viên mới tốt nghiệp cơ hội tích lũy kinh nghiệm thực tế. | Internships provide graduates with opportunities to gain practical experience. | provide graduates with opportunities to |
| 6 | Writing / environment | Nông nghiệp đô thị có thể góp phần đảm bảo an ninh lương thực ở các thành phố đông dân. | Urban farming can contribute to food security in crowded cities. | can contribute to |
| 7 | Writing / work | Giờ làm việc kéo dài có thể gây áp lực đáng kể lên các mối quan hệ cá nhân. | Long working hours can place considerable pressure on personal relationships. | can place considerable pressure on |
| 8 | Writing / environment | Phải thừa nhận rằng xe điện vẫn còn đắt đối với nhiều hộ gia đình. | Admittedly, electric cars remain costly for many households. | Admittedly |
| 9 | Writing / family | Trước đây, các gia đình thường ăn cùng nhau, trong khi ngày nay nhiều người ăn một mình. | In the past, families tended to eat together, whereas nowadays many people eat alone. | In the past / whereas nowadays |
| 10 | Speaking / city | Nếu phải chọn, có lẽ tôi sẽ sống ở một thị trấn nhỏ hơn là một thành phố lớn. | If I had to choose, I'd probably live in a small town rather than a big city. | If I had to choose, I'd probably |
| 11 | Writing / health | Theo quan điểm của tôi, tập thể dục thường xuyên nên là một phần của cuộc sống hằng ngày. | From my perspective, regular exercise should be part of daily life. | From my perspective |
| 12 | Writing / environment | Tôi cho rằng các thành phố nên đầu tư nhiều hơn vào năng lượng tái tạo. | I would argue that cities should invest more in renewable energy. | I would argue that |
| 13 | Writing / work | Ở mức độ lớn, tôi đồng ý rằng giờ làm việc linh hoạt có thể cải thiện sự hài lòng trong công việc. | To a large extent, I agree that flexible working hours can improve job satisfaction. | To a large extent, I agree that |
| 14 | Writing / education | Điều này chủ yếu là do lớp học nhỏ cho phép giáo viên quan tâm đến học sinh nhiều hơn. | This is primarily because small classes allow teachers to give students more attention. | This is primarily because |
| 15 | Writing / city | Một điều cần cân nhắc nữa là làn đường xe đạp an toàn có thể giảm ùn tắc giao thông. | Another important consideration is that safe cycle lanes can reduce traffic congestion. | Another important consideration is that |
| 16 | Writing / family | Hơn nữa, những bữa ăn chung mang đến cho các gia đình thời gian trò chuyện. | Furthermore, shared meals give families time to talk. | Furthermore |
| 17 | Writing / travel | Ví dụ, du khách có thể tìm hiểu các truyền thống địa phương bằng cách ghé thăm những bảo tàng nhỏ. | For example, travellers can learn about local traditions by visiting small museums. | For example |
| 18 | Writing / health | Một ví dụ điển hình là các bể bơi cộng đồng, giúp việc tập luyện dễ tiếp cận hơn. | A good example of this is community swimming pools, which make exercise more accessible. | A good example of this is |
| 19 | Writing / travel | Lấy các lễ hội địa phương làm ví dụ: chúng thu hút du khách và hỗ trợ những doanh nghiệp nhỏ. | Take local festivals, for example: they attract visitors and support small businesses. | Take / for example |
| 20 | Writing / environment | Kết quả là các hộ gia đình có thể giảm rác thải bằng cách tái sử dụng đồ dùng hằng ngày. | As a result, households can reduce waste by reusing everyday items. | As a result |
| 21 | Writing / city | Do đó, người đi làm dành ít thời gian hơn để chờ xe buýt. | Consequently, commuters spend less time waiting for buses. | Consequently |
| 22 | Writing / travel | So với trước đây, du khách có nhiều cơ hội hơn để khám phá những nơi xa xôi. | Compared with the past, travellers have more opportunities to explore distant places. | Compared with the past |
| 23 | Writing / environment | Tuy nhiên, lập luận này bỏ qua thực tế là không gian xanh có thể cải thiện chất lượng không khí đô thị. | Nevertheless, this argument overlooks the fact that green spaces can improve urban air quality. | Nevertheless, this argument overlooks the fact that |
| 24 | Speaking / family | Tôi không hoàn toàn chắc, nhưng tôi đoán những bữa ăn chung giúp các gia đình gắn bó. | I'm not entirely sure, but I'd imagine that shared meals help families stay close. | I'm not entirely sure, but I'd imagine that |
| 25 | Speaking / travel | Điều đó thực sự còn tùy tình huống, nhưng tôi thích du lịch một mình khi tôi cần nghỉ ngơi. | It really depends on the situation, but I enjoy travelling alone when I need a break. | It really depends on the situation |

### Level 3 — Đoạn và bài hoàn chỉnh

#### Giáo dục trực tuyến

**Tiếng Việt:**

Một trong những lợi ích chính của giáo dục trực tuyến là khả năng tiếp cận. Điều này chủ yếu là vì sinh viên có thể tham gia các lớp học bất kể họ sống ở đâu. Ví dụ, sinh viên sống ở vùng nông thôn có thể tham gia các khóa học do các trường đại học lớn cung cấp. Kết quả là nhiều người hơn có thể tiếp cận nền giáo dục chất lượng cao.

**Tiếng Anh tham khảo:**

One of the main benefits of online education is its accessibility. This is primarily because students can attend classes regardless of where they live. For example, students living in rural areas can take courses offered by major universities. As a result, more people can gain access to high-quality education.

**Cấu trúc:** One of the main benefits / This is primarily because / For example / As a result

#### Không gian xanh đô thị

**Tiếng Việt:**

Một trong những lợi ích chính của không gian xanh đô thị là sức khỏe cộng đồng tốt hơn. Điều này chủ yếu là vì công viên cung cấp cho cư dân nơi tập thể dục và thư giãn. Ví dụ, các gia đình có thể đi dạo cùng nhau sau giờ làm. Kết quả là mọi người có thể trở nên năng động hơn và cảm thấy bớt căng thẳng.

**Tiếng Anh tham khảo:**

One of the main benefits of urban green spaces is better public health. This is primarily because parks give residents places to exercise and relax. For example, families can go for walks together after work. As a result, people may become more active and feel less stressed.

**Cấu trúc:** One of the main benefits / This is primarily because / For example / As a result

#### Du học có đáng đầu tư?

**Tiếng Việt:**

Phải thừa nhận rằng du học có thể tốn kém, đặc biệt với các gia đình có thu nhập khiêm tốn. Tuy nhiên, lập luận này bỏ qua thực tế rằng học bổng có thể giảm chi phí cho một số sinh viên. Nói cách khác, rào cản tài chính không cao như nhau đối với mọi ứng viên.

**Tiếng Anh tham khảo:**

Admittedly, studying abroad can be expensive, particularly for families on modest incomes. Nevertheless, this argument overlooks the fact that scholarships may reduce the cost for some students. In other words, the financial barrier is not equally high for every applicant.

**Cấu trúc:** Admittedly / Nevertheless, this argument overlooks the fact that / In other words

### Level 4 — Đoạn và bài hoàn chỉnh

#### Part 1 · Cooking

**Đề:** Do you enjoy cooking?

**Tiếng Việt:**

Có, thực ra là tôi thích. Điều đó thực sự còn tùy tâm trạng của tôi, nhưng tôi thường thấy nấu ăn khá thư giãn sau một ngày dài. Ví dụ, cuối tuần trước tôi đã nấu một nồi súp lớn cho bạn bè, và công sức bỏ ra hoàn toàn xứng đáng.

**Tiếng Anh tham khảo:**

Yes, I do, actually. It really depends on my mood, but I usually find it quite relaxing after a long day. For example, last weekend I made a big pot of soup for my friends, and it was totally worth the effort.

**Cấu trúc:** Yes, I do / It really depends on / For example

#### Part 1 · Work

**Đề:** Do you work or are you a student?

**Tiếng Việt:**

Tôi hiện đang làm thực tập sinh hỗ trợ quản lý sản phẩm. Tôi thực sự thích công việc này, chủ yếu vì nó cho tôi cơ hội học hỏi từ những đồng nghiệp giàu kinh nghiệm. Ví dụ, tôi hỗ trợ theo dõi tiến độ kiểm thử và trao đổi với các nhóm khác nhau.

**Tiếng Anh tham khảo:**

I am currently working as a product management intern. I really enjoy this job, mainly because it gives me opportunities to learn from experienced colleagues. For example, I help track testing progress and communicate with different teams.

**Cấu trúc:** I am currently / mainly because / For example

#### Part 3 · Education

**Đề:** Has technology improved education?

**Tiếng Việt:**

Tôi nghĩ công nghệ đã cải thiện giáo dục ở mức độ lớn. Lý do chính là nó cho phép sinh viên tiếp cận thông tin dễ dàng hơn. Ví dụ, sinh viên hiện có thể tham gia các khóa học trực tuyến từ các trường đại học ở quốc gia khác. Kết quả là họ có nhiều cơ hội học tập hơn. Tuy nhiên, việc phụ thuộc quá nhiều vào công nghệ cũng có thể làm giảm sự tương tác trực tiếp.

**Tiếng Anh tham khảo:**

I think technology has improved education to a large extent. The main reason is that it allows students to access information more easily. For example, students can now take online courses from universities in other countries. As a result, they have more learning opportunities. However, excessive dependence on technology can also reduce face-to-face interaction.

**Cấu trúc:** to a large extent / The main reason is that / For example / As a result / However

#### Part 2 · A memorable trip

**Đề:** Describe a memorable trip. Say where you went, who you went with, what you did and why it was memorable.

**Tiếng Việt:**

Tôi muốn nói về một chuyến đi Đà Nẵng mà tôi đã thực hiện cùng vài người bạn thân khoảng hai năm trước. Nếu tôi nhớ không nhầm, chúng tôi ở đó ba ngày sau khi hoàn thành một học kỳ bận rộn. Chúng tôi chọn thành phố này vì muốn dành thời gian bên biển và thử các món ăn địa phương. Điều tôi nhớ rõ nhất là chúng tôi dậy sớm để ngắm bình minh trên bãi biển. Đường phố vẫn yên tĩnh và không khí trong lành. Chúng tôi ngồi trên cát, nói chuyện và chụp một vài bức ảnh. Một điều khác đáng nhắc đến là một người bạn đã tìm thấy một nhà hàng nhỏ do một gia đình địa phương điều hành. Món ăn vừa ngon vừa có giá phải chăng, nên chúng tôi quay lại đó vào tối hôm sau. Điều khiến chuyến đi đặc biệt đáng nhớ là chúng tôi đã có cơ hội thực sự trò chuyện mà không bị công việc hay việc học làm phiền. Tôi nhớ mình cảm thấy rất vui và thư giãn. Nhìn lại, tôi nghĩ chuyến đi đã giúp tôi nhận ra tầm quan trọng của việc dành thời gian cho những người mình quan tâm. Tôi rất muốn quay lại đó cùng nhóm bạn này.

**Tiếng Anh tham khảo:**

I'd like to talk about a trip to Da Nang that I took with a few close friends about two years ago. If I remember correctly, we stayed there for three days after finishing a busy semester. We chose the city because we wanted to spend time by the sea and try the local food. What I remember most clearly is getting up early to watch the sunrise on the beach. The streets were still quiet and the air was fresh. We sat on the sand, talked and took a few photos. Another thing worth mentioning is that a friend found a small restaurant run by a local family. The food was both delicious and affordable, so we went back the following evening. What made the trip particularly memorable was that we had the chance to really talk without being distracted by work or study. I remember feeling really happy and relaxed. Looking back, I think the trip helped me realise the importance of spending time with people I care about. I would love to return there with the same group of friends.

**Cấu trúc:** I'd like to talk about / If I remember correctly / What I remember most clearly / Another thing worth mentioning / What made the trip particularly memorable / Looking back

### Level 5 — Đoạn và bài hoàn chỉnh

#### Task 2 · Education & work

**Đề:** Universities should focus on practical skills rather than theoretical knowledge. To what extent do you agree or disagree?

**Tiếng Việt:**

Một số người cho rằng các trường đại học nên tập trung vào kỹ năng thực tiễn thay vì kiến thức lý thuyết. Mặc dù lý thuyết tạo nền tảng quan trọng, tôi cho rằng các trường đại học nên kết hợp cả hai. Cách tiếp cận này có thể giúp sinh viên chuẩn bị cho công việc và thích ứng với những thay đổi trong tương lai.

Một trong những lý do chính là kỹ năng thực tiễn giúp sinh viên chuyển kiến thức thành hành động. Điều này chủ yếu là vì nhà tuyển dụng thường cần những người có thể giải quyết các vấn đề thực tế và làm việc hiệu quả với người khác. Ví dụ, sinh viên quản lý thông tin có thể học cách tổ chức dữ liệu trong lớp, nhưng một kỳ thực tập cho phép họ áp dụng kiến thức đó vào một dự án thực tế. Kết quả là họ có thể bước vào môi trường làm việc với sự tự tin lớn hơn và hiểu rõ hơn trách nhiệm hằng ngày của mình. Những dự án như vậy cũng khuyến khích sinh viên đặt câu hỏi, phản hồi góp ý và giải thích quyết định của mình cho người khác, những khả năng khó phát triển chỉ bằng việc ghi nhớ thông tin.

Một yếu tố quan trọng khác là kiến thức lý thuyết vẫn cần thiết cho sự phát triển lâu dài. Các công cụ và quy trình có thể thay đổi nhanh chóng, nên chỉ biết thực hiện một nhiệm vụ cụ thể có thể là chưa đủ. Ví dụ, một sinh viên hiểu các nguyên tắc phân tích dữ liệu có thể học phần mềm mới dễ dàng hơn người chỉ ghi nhớ một bộ hướng dẫn. Phải thừa nhận rằng việc học lý thuyết đôi khi có thể có vẻ xa rời công việc thực tế. Tuy nhiên, hạn chế này có thể được giải quyết bằng cách kết nối các bài giảng với nghiên cứu tình huống và các dự án có hướng dẫn.

Tóm lại, tôi tin rằng các trường đại học nên kết hợp đào tạo thực tiễn với nền tảng lý thuyết vững chắc. Kỹ năng thực tiễn hỗ trợ sinh viên trong công việc đầu tiên, trong khi lý thuyết giúp họ tiếp tục học hỏi và thích ứng trong suốt sự nghiệp.

**Tiếng Anh tham khảo:**

Some people believe that universities should focus on practical skills rather than theoretical knowledge. Although theory provides an important foundation, I would argue that universities should combine both. This approach can help students prepare for employment and adapt to future changes.

One of the main reasons is that practical skills help students turn knowledge into action. This is primarily because employers often need people who can solve real problems and work effectively with others. For example, information management students may learn how to organise data in class, but an internship allows them to apply that knowledge to a real project. As a result, they can enter the workplace with greater confidence and a clearer understanding of their daily responsibilities. Such projects also encourage students to ask questions, respond to feedback and explain their decisions to others, abilities that are difficult to develop simply by memorising information.

Another important consideration is that theoretical knowledge remains necessary for long-term development. Tools and procedures can change rapidly, so knowing how to perform one particular task may not be enough. For example, a student who understands the principles of data analysis can learn new software more easily than someone who has only memorised a set of instructions. Admittedly, studying theory can sometimes seem disconnected from practical work. However, this limitation can be addressed by connecting lectures with case studies and guided projects.

In conclusion, I believe that universities should combine practical training with a strong theoretical foundation. Practical skills support students in their first jobs, while theory helps them continue learning and adapting throughout their careers.

**Cấu trúc:** I would argue that / One of the main reasons is that / This is primarily because / For example / As a result / Another important consideration is that / Admittedly / In conclusion

#### Task 1 · Thay đổi số liệu

**Đề:** Bảng luyện tập giả định: tỷ lệ người đi làm bằng xe buýt / ô tô tại một thành phố. Năm 2000: 20% / 60%; 2010: 30% / 50%; 2020: 40% / 40%. Tóm tắt và so sánh các đặc điểm chính.

**Tiếng Việt:**

Bảng cho biết thông tin về tỷ lệ người đi làm bằng xe buýt và ô tô tại một thành phố trong các năm 2000, 2010 và 2020.

Nhìn chung, tỷ lệ người dùng xe buýt tăng đều, trong khi tỷ lệ đi bằng ô tô giảm. Ô tô phổ biến hơn vào đầu giai đoạn, nhưng hai hình thức có tỷ lệ bằng nhau vào năm 2020.

Năm 2000, xe buýt chiếm 20% số người đi làm, so với 60% đi bằng ô tô. Điều này có nghĩa là tỷ lệ dùng ô tô cao gấp ba lần tỷ lệ dùng xe buýt. Đến năm 2010, tỷ lệ dùng xe buýt đã tăng lên 30%, trong khi tỷ lệ dùng ô tô giảm xuống 50%. Khoảng cách vì vậy thu hẹp từ 40 xuống 20 điểm phần trăm.

Trong thập kỷ tiếp theo, tỷ lệ dùng xe buýt tăng thêm 10 điểm phần trăm và đạt 40%. Ngược lại, tỷ lệ dùng ô tô giảm xuống 40%. Trong toàn bộ giai đoạn, tỷ lệ dùng xe buýt tăng gấp đôi, còn tỷ lệ dùng ô tô giảm 20 điểm phần trăm.

**Tiếng Anh tham khảo:**

The table provides information about the percentages of commuters travelling by bus and car in a city in 2000, 2010 and 2020.

Overall, the proportion of bus users increased steadily, whereas the percentage travelling by car declined. Cars were more popular at the beginning of the period, but the two modes had equal shares by 2020.

In 2000, buses accounted for 20% of commuters, compared with 60% for cars. This means that the figure for cars was three times the figure for buses. By 2010, the bus share had risen to 30%, while the car share had fallen to 50%. The gap therefore narrowed from 40 to 20 percentage points.

Over the following decade, the bus share increased by another 10 percentage points to reach 40%. By contrast, the proportion of car users fell to 40%. Across the whole period, the bus share doubled, while the car share decreased by 20 percentage points.

**Cấu trúc:** The table provides information about / Overall / whereas / compared with / By contrast

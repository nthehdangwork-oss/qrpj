# Bộ tài liệu FrameLab

Xuất ngày 06/10/2026 từ các tài liệu dự án hiện có.

## Lưu vào máy Windows

1. Tải `ielts.zip`.
2. Nhấp chuột phải → Extract All / Giải nén tất cả.
3. Chọn thư mục `D:\cá nhân`.
4. Tài liệu nằm trong `D:\cá nhân\ielts`.

## Danh mục

- `tai-lieu/spec.md`: đặc tả hiện hành, gồm nội dung v1.2 và phần bổ sung v1.3 về MCP.
- `tai-lieu/ngan-hang-bai-hoc.md`: toàn bộ 59 bài trong lộ trình cố định, xuất từ mã nguồn.
- `phien-ban-cu/spec-v1.2.md`: bản đặc tả trước bổ sung MCP.
- `phien-ban-cu/spec-v1.1-goc.txt`: tài liệu yêu cầu gốc đã cung cấp.
- `ky-thuat/MCP-va-cap-nhat.md`: endpoint, lịch, hướng dẫn cập nhật và trạng thái kiểm tra khi thiết lập.
- `ky-thuat/README-starter.md`: hướng dẫn kỹ thuật gốc của nền tảng starter; một số mô tả cấu trúc ban đầu không phản ánh chức năng FrameLab đã bổ sung.
- `ky-thuat/schema.ts`, `ky-thuat/drizzle/`: định nghĩa cơ sở dữ liệu và các phiên bản migration.

Thư mục docs chứa bộ tài liệu trước đây. Mã nguồn đầy đủ nằm ở thư mục cha; bài bổ sung nằm trong data. Xem HUONG-DAN.md ở thư mục gốc.

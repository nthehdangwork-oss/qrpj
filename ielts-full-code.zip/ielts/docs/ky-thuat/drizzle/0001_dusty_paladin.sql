CREATE TABLE `learning_sessions` (
	`user_id` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `attempts` ADD `stage` text DEFAULT 'C' NOT NULL;--> statement-breakpoint
ALTER TABLE `attempts` ADD `independent` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attempts` ADD `self_confirmed` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attempts` ADD `course_version` text DEFAULT '1.0' NOT NULL;--> statement-breakpoint
ALTER TABLE `attempts` ADD `result` text;--> statement-breakpoint
ALTER TABLE `attempts` ADD `payload` text;--> statement-breakpoint
CREATE INDEX `attempts_user_item_day` ON `attempts` (`user_id`,`item_id`,`day`);
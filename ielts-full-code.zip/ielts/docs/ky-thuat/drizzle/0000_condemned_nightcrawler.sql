CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`item_id` text NOT NULL,
	`correct` integer NOT NULL,
	`hinted` integer NOT NULL,
	`xp` integer NOT NULL,
	`created` integer NOT NULL,
	`day` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `attempts_user_created` ON `attempts` (`user_id`,`created`);
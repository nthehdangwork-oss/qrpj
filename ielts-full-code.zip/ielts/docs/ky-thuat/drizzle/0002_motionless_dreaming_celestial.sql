CREATE TABLE `content_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`created` integer NOT NULL,
	`details` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `online_exercises` (
	`id` text PRIMARY KEY NOT NULL,
	`source_url` text NOT NULL,
	`data` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `online_sources` (
	`url` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`checked` integer NOT NULL,
	`status` text NOT NULL
);
